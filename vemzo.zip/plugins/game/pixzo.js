import crypto from "node:crypto"

const pluginConfig = {
  name: "pixzo",
  alias: ["pixzo"],
  category: "game",
  description: "PIXEL MAZE",
  usage: ".pixzo",
  example: ".pixzo",
  isOwner: false,
  isPremium: false,
  isGroup: true,
  isPrivate: false,
  isAdmin: false,
  isBotAdmin: false,
  skipRegistration: true,
  cooldown: 5,
  energi: 0,
  isEnabled: true,
};

async function handler(m, { sock }) {
  const htmlCode = `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>PIXEL MAZE</title><style>
*{box-sizing:border-box;margin:0;padding:0;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent}html,body{width:100%;height:100%;min-height:600px;overflow:hidden;background:#000;font-family:monospace}body{position:relative;width:100%;max-width:700px;min-height:600px;margin:0 auto}canvas{position:absolute;inset:0;display:block;width:100%;height:100%;min-width:1px;min-height:1px;background:#000;image-rendering:pixelated}.hud{position:absolute;top:max(8px,env(safe-area-inset-top));left:3%;right:3%;z-index:5;display:flex;justify-content:space-between;color:#fff900;font-weight:bold;text-shadow:0 0 8px #fff900;font-size:clamp(12px,2.8vw,16px);pointer-events:none}#score{font-size:clamp(20px,5vw,28px)}#level{color:#39ffff;text-shadow:0 0 8px #39ffff}.overlay{position:absolute;top:0;right:0;bottom:0;left:0;width:100%;height:100%;z-index:20;display:flex;align-items:center;justify-content:center;padding:max(8px,env(safe-area-inset-top)) max(8px,4vw) max(8px,env(safe-area-inset-bottom));background:rgba(0,0,0,.9);overflow:hidden}.panel{width:min(94vw,450px);max-width:450px;height:auto;max-height:calc(100% - 16px);overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;padding:clamp(14px,4vw,22px);text-align:center;background:#02030a;border:3px solid #176cff;box-shadow:0 0 0 3px #06248a,0 0 35px rgba(0,100,255,.5);flex:0 1 auto}.panel h1{color:#fff900;font-size:clamp(23px,7vw,32px);line-height:1.1;margin-bottom:8px;text-shadow:0 0 12px #fff900}.desc{color:#39ffff;font-size:clamp(11px,3.2vw,14px);line-height:1.5}.st{margin:10px 0 6px;color:#fff;font-size:10px;letter-spacing:2px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}.btn{min-height:44px;border:2px solid #176cff;background:#00102c;color:#39ffff;font-family:monospace;font-weight:bold;font-size:clamp(10px,3vw,13px);touch-action:manipulation}.btn.sel{border-color:#fff900;color:#fff900;box-shadow:0 0 15px rgba(255,249,0,.45);background:#171400}.char{min-height:clamp(56px,14vw,70px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}.icon{font-size:clamp(20px,6vw,27px)}.name{font-size:9px}.start{margin-top:12px;padding:11px 20px;border:3px solid #fff900;background:#000;color:#fff900;font:700 clamp(12px,3.8vw,16px) monospace;width:100%;touch-action:manipulation}.controls{position:absolute;left:50%;bottom:max(8px,env(safe-area-inset-bottom));transform:translateX(-50%);z-index:10;display:grid;grid-template-columns:clamp(54px,17vw,78px) clamp(54px,17vw,78px) clamp(54px,17vw,78px);grid-template-rows:clamp(54px,17vw,78px) clamp(54px,17vw,78px);gap:clamp(6px,3.2vw,18px);touch-action:none}.ctrl{width:100%;height:100%;border:3px solid #176cff;border-radius:16px;background:#00102c;color:#fff900;font:bold clamp(22px,7vw,33px) monospace;box-shadow:0 0 14px rgba(0,100,255,.55);touch-action:none}.ctrl:active,.ctrl.active{transform:scale(.9);background:#08265c}.up{grid-column:2}.left{grid-column:1;grid-row:2}.down{grid-column:2;grid-row:2}.right{grid-column:3;grid-row:2}.hide{display:none}@media(max-height:560px){.overlay{align-items:flex-start;padding-top:6px;padding-bottom:6px}.panel{max-height:calc(100% - 12px);padding:10px}.panel h1{font-size:clamp(20px,6vw,28px)}.st{margin:7px 0 4px}.btn{min-height:38px}.char{min-height:46px}.start{margin-top:9px;padding:9px 16px}.controls{bottom:2px;transform:translateX(-50%) scale(.75);transform-origin:bottom center}}@media(max-height:420px){.overlay{padding:4px 8px}.panel{width:min(94vw,450px);max-height:calc(100% - 8px);padding:6px 7px;border-width:2px}.panel h1{font-size:clamp(18px,5.5vw,23px);margin-bottom:4px}.desc{font-size:clamp(9px,2.5vw,11px);line-height:1.25}.st{margin:4px 0 3px;font-size:9px;letter-spacing:1.5px}.grid{gap:4px}.btn{min-height:30px;font-size:clamp(8px,2.5vw,11px);border-width:2px}.char{min-height:34px;gap:1px}.icon{font-size:clamp(14px,4vw,19px)}.name{font-size:7px}.start{margin-top:5px;padding:6px 10px;border-width:2px;font-size:clamp(9px,3vw,12px)}.controls{bottom:1px;transform:translateX(-50%) scale(.60);transform-origin:bottom center}}@media(max-height:360px){.overlay{padding:2px 6px}.panel{padding:4px 5px}.panel h1{font-size:18px}.desc{font-size:9px}.st{margin:3px 0 2px;font-size:8px}.btn{min-height:27px}.char{min-height:30px}.start{margin-top:4px;padding:5px 8px}}
@media(orientation:landscape){.controls{transform:translateX(-50%) scale(.62);bottom:1px}.panel{max-height:calc(100% - 8px);padding:9px}.char{min-height:42px}.btn{min-height:36px}}
</style></head><body><canvas id="game"></canvas><div class="hud"><span>● <b id="lives">3</b></span><span id="score">0000</span><span>LEVEL <b id="level">1</b></span></div><div id="overlay" class="overlay"><div class="panel"><h1 id="title">PIXEL MAZE</h1><div class="desc" id="desc">Pilih mode dan karakter, lalu mulai permainan.</div><div class="st">DIFFICULTY</div><div class="grid"><button class="btn mode" data-v="easy">EASY</button><button class="btn mode sel" data-v="medium">MEDIUM</button><button class="btn mode" data-v="hard">HARD</button></div><div class="st">PILIH KARAKTER</div><div class="grid"><button class="btn char sel" data-v="pixel"><span class="icon">●</span><span class="name">PIXEL</span></button><button class="btn char" data-v="alien"><span class="icon">👽</span><span class="name">ALIEN</span></button><button class="btn char" data-v="devil"><span class="icon">😈</span><span class="name">IBLIS</span></button><button class="btn char" data-v="robot"><span class="icon">🤖</span><span class="name">ROBOT</span></button><button class="btn char" data-v="ninja"><span class="icon">🥷</span><span class="name">NINJA</span></button><button class="btn char" data-v="mage"><span class="icon">🧙</span><span class="name">MAGE</span></button></div><button id="start" class="start">START GAME</button></div></div><div class="controls"><button class="ctrl up" data-d="up">▲</button><button class="ctrl left" data-d="left">◀</button><button class="ctrl down" data-d="down">▼</button><button class="ctrl right" data-d="right">▶</button></div><script>
const c=document.getElementById('game'),x=c.getContext('2d');x.imageSmoothingEnabled=false;const C=21,R=25;let W,H,t,ox,oy,map=[],foods=[],enemies=[],parts=[],teleportEffects=[],bombs=[],explosions=[],running=false,score=0,lives=3,level=1,diff='medium',char='pixel',last=0,levelMessage=false,level10SkillUntil=0;
const D={easy:[5.1,1.15,1.45,5.5],medium:[5.7,1.5,2,7],hard:[7.2,2.35,3.25,10]},COL={pixel:'#fff900',alien:'#39ff72',devil:'#ff315d',robot:'#b9c7d9',ninja:'#7777ff',mage:'#bd65ff'};const P={x:1,y:1,dx:0,dy:0,nx:0,ny:0};
function resize(){const v=window.visualViewport;W=Math.max(1,Math.floor((v&&v.width)||window.innerWidth||document.documentElement.clientWidth||c.clientWidth||1));H=Math.max(1,Math.floor((v&&v.height)||window.innerHeight||document.documentElement.clientHeight||c.clientHeight||1));c.style.width=W+'px';c.style.height=H+'px';c.width=W;c.height=H;t=Math.max(10,Math.floor(Math.min(W/(C+2),H/(R+3))));ox=Math.floor((W-C*t)/2);oy=Math.floor((H-R*t)/2);x.setTransform(1,0,0,1,0,0);x.imageSmoothingEnabled=false}addEventListener('resize',resize,{passive:true});addEventListener('orientationchange',()=>setTimeout(resize,150),{passive:true});if(window.visualViewport)window.visualViewport.addEventListener('resize',resize,{passive:true});resize();function wall(a,b){return a<0||b<0||a>=C||b>=R||map[b][a]==='#'}
function maze(){map=Array.from({length:R},()=>Array(C).fill('#'));function carve(a,b){map[b][a]='.';let q=[[2,0],[-2,0],[0,2],[0,-2]].sort(()=>Math.random()-.5);for(const[d,e]of q){let A=a+d,B=b+e;if(A>0&&A<C-1&&B>0&&B<R-1&&wall(A,B)){map[b+e/2][a+d/2]='.';carve(A,B)}}}carve(1,1);for(let i=0;i<18+level*2;i++){let a=1+Math.random()*(C-2)|0,b=1+Math.random()*(R-2)|0;if(wall(a,b)){let n=(!wall(a+1,b))+(!wall(a-1,b))+(!wall(a,b+1))+(!wall(a,b-1));if(n>=2)map[b][a]='.'}}}
function roads(md=6){let a=[];for(let y=1;y<R-1;y++)for(let z=1;z<C-1;z++)if(!wall(z,y)&&Math.abs(z-P.x)+Math.abs(y-P.y)>=md)a.push([z,y]);return a[Math.random()*a.length|0]||[1,1]}
function foodsMake(){foods=[];for(let y=1;y<R-1;y++)for(let z=1;z<C-1;z++)if(map[y][z]==='.'&&(z!==1||y!==1)&&Math.random()<.62)foods.push({x:z,y,e:0})}
function dirs(e){let a=Math.round(e.x),b=Math.round(e.y),q=[[1,0],[-1,0],[0,1],[0,-1]].filter(d=>!wall(a+d[0],b+d[1]));if(q.length>1&&e.dx!==0||e.dy!==0)q=q.filter(d=>d[0]!==-e.dx||d[1]!==-e.dy)||q;return q}
function choose(e){let q=dirs(e);if(!q.length){e.dx=e.dy=0;return}if(e.alert){let px=P.x+(P.dx||P.nx)*2,py=P.y+(P.dy||P.ny)*2;q.sort((a,b)=>(Math.abs(Math.round(e.x)+a[0]-px)+Math.abs(Math.round(e.y)+a[1]-py))-(Math.abs(Math.round(e.x)+b[0]-px)+Math.abs(Math.round(e.y)+b[1]-py)))}else if(e.dx||e.dy){let f=q.find(d=>d[0]===e.dx&&d[1]===e.dy);if(f&&Math.random()<.7){e.dx=f[0];e.dy=f[1];return}}let qx=q[Math.random()*q.length|0];e.dx=qx[0];e.dy=qx[1]}
function enemiesMake(){enemies=[];let z=D[diff];for(let i=0;i<4;i++){let p=roads(i===3?10:7);enemies.push({x:p[0],y:p[1],rx:p[0],ry:p[1],dx:0,dy:0,s:z[1]+level*.04+(i===3?.15:0),ch:z[2]+level*.06+(i===3?.25:0),det:z[3]+(i===3?1:0),alert:0,special:i===3,shadowBoss:false,color:['#ff315d','#39eaff','#ff65ed','#9b35ff'][i],tele:5000,teleCooldown:Math.max(3000,5000-level*150),teleporting:false,teleportScale:1,splitActive:false,splitTimer:0,splitCooldown:5000})}enemies.forEach(choose)}
function startGame(){score=0;lives=3;level=1;parts=[];teleportEffects=[];bombs=[];explosions=[];levelMessage=false;level10SkillUntil=0;maze();foodsMake();enemiesMake();P.x=P.y=1;P.dx=P.dy=P.nx=P.ny=0;resize();overlay.classList.add('hide');running=true;last=performance.now();ui();draw();requestAnimationFrame(loop)}
function movePlayer(dt){let sp=D[diff][0],cx=Math.round(P.x),cy=Math.round(P.y);if((P.nx||P.ny)&&!wall(cx+P.nx,cy+P.ny)){P.dx=P.nx;P.dy=P.ny}if(!P.dx&&!P.dy)return;if(wall(Math.round(P.x)+P.dx,Math.round(P.y)+P.dy)){P.dx=P.dy=0;return}if(P.dx){let tar=Math.round(P.x)+P.dx;P.x+=P.dx*sp*dt/1000;if((P.dx>0&&P.x>tar)||(P.dx<0&&P.x<tar))P.x=tar}if(P.dy){let tar=Math.round(P.y)+P.dy;P.y+=P.dy*sp*dt/1000;if((P.dy>0&&P.y>tar)||(P.dy<0&&P.y<tar))P.y=tar}let a=Math.round(P.x),b=Math.round(P.y);foods.forEach(f=>{if(!f.e&&f.x===a&&f.y===b){f.e=1;score+=10;foodEffect(f.x,f.y)}});if(foods.every(f=>f.e)){if(level>=10){over('YOU WIN!','Selamat wih keren kamu menang!<br>Ayok lanjut ke level selanjutnya.<br><br>SKOR: '+score);return}level++;levelMessage=true;running=false;document.getElementById('title').textContent='LEVEL '+level+' SELESAI!';document.getElementById('desc').innerHTML='Selamat wih keren kamu menang!<br>Ayok lanjut ke level selanjutnya.<br><br>LEVEL BERIKUTNYA: '+level;document.getElementById('start').textContent='LANJUT KE LEVEL '+level;overlay.classList.remove('hide')}ui()}
function clearBossShadows(e){for(let i=enemies.length-1;i>=0;i--)if(enemies[i].shadowBoss&&enemies[i].bossOwner===e)enemies.splice(i,1);e.splitActive=false;e.splitTimer=5000}function spawnBossShadows(e){if(!e.special||e.shadowBoss||e.splitActive)return;for(let i=0;i<2;i++){let p=roads(5);let s={x:p[0],y:p[1],rx:p[0],ry:p[1],dx:0,dy:0,s:e.s*.98,ch:e.ch*1.02,det:e.det,alert:0,special:true,shadowBoss:true,bossOwner:e,color:'#9b35ff',tele:999999,teleCooldown:999999,teleporting:false,teleportScale:1,splitActive:false,splitTimer:0,splitCooldown:5000,shadowLife:10000};enemies.push(s);createTeleportEffect(s.x,s.y);choose(s)}e.splitActive=true;e.splitTimer=10000}function teleportEnemy(e){createTeleportEffect(e.x,e.y);let p=roads(8);e.teleporting=true;e.teleportScale=.05;e.x=p[0];e.y=p[1];e.rx=p[0];e.ry=p[1];e.dx=e.dy=0;if(e.special&&!e.shadowBoss){createTeleportEffect(e.x,e.y);if(diff==='hard'||level>=10)spawnBossShadows(e)}createTeleportEffect(e.x,e.y);e.tele=e.teleCooldown;choose(e)}
function moveEnemy(e,dt){if(e.shadowBoss){e.shadowLife-=dt;if(e.shadowLife<=0){let i=enemies.indexOf(e);if(i>=0)enemies.splice(i,1);return}}if(e.special&&!e.shadowBoss){e.tele-=dt;if(e.tele<=0&&!e.teleporting)teleportEnemy(e);if(e.teleporting){e.teleportScale+=(1-e.teleportScale)*.18;if(Math.abs(1-e.teleportScale)<.025){e.teleportScale=1;e.teleporting=false}}if(e.splitActive){e.splitTimer-=dt;if(e.splitTimer<=0)clearBossShadows(e)}else if((diff==='hard'||level>=10)&&e.splitTimer>0){e.splitTimer-=dt;if(e.splitTimer<=0)spawnBossShadows(e)}if(level>=10&&level10SkillUntil>performance.now()&&Math.random()<0.018){throwBomb(e)}}let dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy);e.alert=d<e.det?1:d>e.det+3?0:e.alert;let sp=(e.alert?e.ch:e.s)*(e.special&&e.alert?1.08:1);let m=sp*dt/1000,cx=Math.round(e.x),cy=Math.round(e.y);if(Math.abs(e.x-cx)<.04&&Math.abs(e.y-cy)<.04){e.x=cx;e.y=cy;if(!e.dx&&!e.dy||wall(cx+e.dx,cy+e.dy)||Math.random()<.08)choose(e)}if(e.dx){let tar=Math.round(e.x)+e.dx;if(wall(tar,cy)){e.dx=e.dy=0;choose(e)}else{e.x+=e.dx*m;if((e.dx>0&&e.x>tar)||(e.dx<0&&e.x<tar)){e.x=tar;choose(e)}}}else if(e.dy){let tar=Math.round(e.y)+e.dy;if(wall(cx,tar)){e.dx=e.dy=0;choose(e)}else{e.y+=e.dy*m;if((e.dy>0&&e.y>tar)||(e.dy<0&&e.y<tar)){e.y=tar;choose(e)}}}e.rx+=(e.x-e.rx)*.35;e.ry+=(e.y-e.ry)*.35}
function throwBomb(e){let bx=ox+e.x*t+t/2,by=oy+e.y*t+t/2;bombs.push({x:bx,y:by,vx:0,vy:0,life:6000,pulse:0,trail:0});createTeleportEffect(e.x,e.y)}
function updateBombs(dt){for(let i=bombs.length-1;i>=0;i--){let b=bombs[i];let tx=ox+P.x*t+t/2,ty=oy+P.y*t+t/2,dx=tx-b.x,dy=ty-b.y,d=Math.hypot(dx,dy)||1;b.vx+=(dx/d)*.045*dt;b.vy+=(dy/d)*.045*dt;let cap=2.8,sp=Math.hypot(b.vx,b.vy);if(sp>cap){b.vx=b.vx/sp*cap;b.vy=b.vy/sp*cap}b.x+=b.vx;b.y+=b.vy;b.life-=dt;b.pulse+=dt;if(Math.hypot(tx-b.x,ty-b.y)<t*.45){createBombExplosion(b.x,b.y);createHitEffect(P.x,P.y);b.life=0;lives--;ui();if(lives<=0){over('GAME OVER');return}P.x=P.y=1;P.dx=P.dy=P.nx=P.ny=0}if(b.life<=0)bombs.splice(i,1)}}
function createBombExplosion(px,py){explosions.push({x:px,y:py,r:2,life:34,max:34});for(let i=0;i<55;i++){let a=Math.random()*Math.PI*2,s=1.5+Math.random()*5.5;parts.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:18+Math.random()*25,type:i%3===0?'hit':'fire'})}}
function drawBombs(){for(const b of bombs){b.trail+=1;let r=t*(.17+.045*Math.sin(b.pulse*.012));x.save();x.translate(b.x,b.y);let flick=.85+.15*Math.sin(b.pulse*.025);x.shadowBlur=28;x.shadowColor='#ff5a00';x.fillStyle='#ffb000';x.beginPath();x.moveTo(0,-r*2.2*flick);x.lineTo(-r*.65,-r*.75);x.lineTo(-r*.35,-r*1.25);x.lineTo(0,-r*.7);x.lineTo(r*.38,-r*1.45);x.lineTo(r*.72,-r*.72);x.closePath();x.fill();x.shadowBlur=22;x.shadowColor='#ff315d';x.fillStyle='#161616';x.beginPath();x.arc(0,0,r,0,7);x.fill();x.strokeStyle='#ff7a00';x.lineWidth=2;x.beginPath();x.arc(0,0,r*1.65,0,7);x.stroke();x.fillStyle='#fff900';x.beginPath();x.arc(r*.35,-r*.35,r*.12,0,7);x.fill();x.strokeStyle='#ffbd00';x.lineWidth=3;x.beginPath();x.moveTo(r*.35,-r*.8);x.quadraticCurveTo(r*.8,-r*1.25,r*1.05,-r*.85);x.stroke();x.restore()}}
function drawBombExplosions(){for(let i=explosions.length-1;i>=0;i--){let e=explosions[i];e.r+=(t*1.55-e.r)*.28;e.life--;let a=e.life/e.max;x.save();x.globalAlpha=a;x.shadowBlur=35;x.shadowColor='#ff4b00';x.strokeStyle='#ff7a00';x.lineWidth=Math.max(2,t*.07);x.beginPath();x.arc(e.x,e.y,e.r,0,7);x.stroke();x.fillStyle='#fff900';x.beginPath();x.arc(e.x,e.y,Math.max(3,e.r*.28),0,7);x.fill();x.fillStyle='#ff5a00';for(let k=0;k<12;k++){let ang=k*Math.PI*2/12+e.life*.08,rr=e.r*(.8+Math.sin(k*2+e.life*.2)*.2);x.fillRect(e.x+Math.cos(ang)*rr,e.y+Math.sin(ang)*rr,Math.max(2,t*.06),Math.max(2,t*.06))}x.restore();if(e.life<=0)explosions.splice(i,1)}}
function hit(){for(const e of enemies)if(Math.hypot(P.x-e.x,P.y-e.y)<(e.special?.72:.48)){createHitEffect(P.x,P.y);lives--;ui();if(lives<=0){over('GAME OVER');return}P.x=P.y=1;P.dx=P.dy=P.nx=P.ny=0;enemies.forEach(e=>{let p=roads(7);e.x=e.rx=p[0];e.y=e.ry=p[1];e.alert=0;e.dx=e.dy=0;choose(e)});break}}
function over(msg,custom){running=false;document.getElementById('title').textContent=msg;document.getElementById('desc').innerHTML=custom||('SKOR: '+score+'<br>LEVEL: '+level);document.getElementById('start').textContent='MAIN LAGI';overlay.classList.remove('hide')}
function ui(){document.getElementById('score').textContent=String(score).padStart(4,'0');document.getElementById('lives').textContent=lives;document.getElementById('level').textContent=level}
function draw(){x.fillStyle='#000';x.fillRect(0,0,W,H);for(let y=0;y<R;y++)for(let z=0;z<C;z++){let X=ox+z*t,Y=oy+y*t;if(map[y][z]==='#'){x.fillStyle='#006eff';x.fillRect(X+1,Y+1,t-2,t-2);x.fillStyle='#00142f';x.fillRect(X+4,Y+4,Math.max(1,t-8),Math.max(1,t-8))}}for(const f of foods)if(!f.e){x.fillStyle='#fff900';x.shadowBlur=10;x.shadowColor='#fff900';x.beginPath();x.arc(ox+f.x*t+t/2,oy+f.y*t+t/2,Math.max(3,t*.12),0,7);x.fill()}x.shadowBlur=0;drawP();for(const e of enemies)drawE(e);drawBombs();drawBombExplosions();drawTeleportEffects();drawParticles()}
function foodEffect(px,py){let X=ox+px*t+t/2,Y=oy+py*t+t/2;for(let i=0;i<12;i++){let a=Math.random()*Math.PI*2,s=.6+Math.random()*2.2;parts.push({x:X,y:Y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:18+Math.random()*14,type:'food'})}}
function drawP(){let X=ox+P.x*t+t/2,Y=oy+P.y*t+t/2,col=COL[char],bob=Math.sin(performance.now()*.012)*t*.025;x.save();x.translate(X,Y+bob);x.shadowBlur=18;x.shadowColor=col;x.fillStyle=col;if(char==='pixel'){let mouth=.22+Math.abs(Math.sin(performance.now()*.012))*.22;let ang=P.dx<0?Math.PI:P.dy<0?-Math.PI/2:P.dy>0?Math.PI/2:0;x.rotate(ang);x.beginPath();x.moveTo(0,0);x.arc(0,0,t*.34,mouth,Math.PI*2-mouth);x.lineTo(0,0);x.fill()}else{let r=t*.30;x.beginPath();x.arc(0,0,r,0,Math.PI*2);x.fill();x.shadowBlur=0;x.fillStyle='#000';x.fillRect(-t*.11,-t*.07,t*.08,t*.09);x.fillRect(t*.03,-t*.07,t*.08,t*.09)}x.restore()}
function drawE(e){let X=ox+e.rx*t+t/2,Y=oy+e.ry*t+t/2,p=1+Math.sin(performance.now()*.008)*.05;x.save();x.translate(X,Y);x.scale(p*(e.special?e.teleportScale*1.55:1),p*(e.special?e.teleportScale*1.55:1));x.fillStyle=e.color;x.shadowBlur=e.alert?(e.special?35:25):(e.special?22:10);x.shadowColor=e.color;x.beginPath();x.arc(0,e.special?-5:-2,t*(e.special?.63:.38),Math.PI,0);x.lineTo(t*(e.special?.63:.38),t*(e.special?.52:.35));x.lineTo(t*(e.special?.35:.38),t*(e.special?.34:.18));x.lineTo(0,t*(e.special?.52:.35));x.lineTo(-t*(e.special?.35:.38),t*(e.special?.34:.18));x.lineTo(-t*(e.special?.63:.38),t*(e.special?.52:.35));x.closePath();x.fill();x.shadowBlur=0;x.fillStyle='#fff';let s=e.special?1.6:1;x.fillRect(-t*.2*s,-t*.14*s,t*.13*s,t*.17*s);x.fillRect(t*.07*s,-t*.14*s,t*.13*s,t*.17*s);x.fillStyle='#000';x.fillRect(-t*.16*s,-t*.08*s,t*.06*s,t*.07*s);x.fillRect(t*.11*s,-t*.08*s,t*.06*s,t*.07*s);if(e.special&&e.teleporting){x.strokeStyle='#39ffff';x.lineWidth=3;x.beginPath();x.arc(0,0,t*.9,0,Math.PI*2);x.stroke()}if(e.special&&e.shadows){for(const sh of e.shadows){x.save();x.globalAlpha=sh.a; x.translate(sh.ox*t,sh.oy*t); x.fillStyle='#7b35ff'; x.shadowBlur=18; x.shadowColor='#39ffff'; x.beginPath();x.arc(0,-5,t*.63,Math.PI,0);x.lineTo(t*.63,t*.52);x.lineTo(t*.35,t*.34);x.lineTo(0,t*.52);x.lineTo(-t*.35,t*.34);x.lineTo(-t*.63,t*.52);x.closePath();x.fill();x.restore()}}x.restore();if(e.special){x.fillStyle='#39ffff';x.font='bold '+Math.max(8,t*.27)+'px monospace';x.textAlign='center';x.fillText('TELEPORT',X,Y-t*.88)}else if(e.alert){x.fillStyle='#fff900';x.font='bold '+Math.max(12,t*.6)+'px monospace';x.textAlign='center';x.fillText('!',X,Y-t*.55)}}
function createTeleportEffect(px,py){let X=ox+px*t+t/2,Y=oy+py*t+t/2;teleportEffects.push({x:X,y:Y,r:5,max:t*1.9,life:45});for(let i=0;i<35;i++){let a=Math.random()*Math.PI*2,s=1+Math.random()*4;parts.push({x:X,y:Y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:20+Math.random()*25,type:'tele'})}}
function createHitEffect(px,py){let X=ox+px*t+t/2,Y=oy+py*t+t/2;for(let i=0;i<30;i++){let a=Math.random()*Math.PI*2,s=1+Math.random()*4;parts.push({x:X,y:Y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:20+Math.random()*20,type:'hit'})}}
function drawTeleportEffects(){for(let i=teleportEffects.length-1;i>=0;i--){let e=teleportEffects[i];e.r+=(e.max-e.r)*.13;e.life--;x.save();x.globalAlpha=e.life/45;x.shadowBlur=25;x.shadowColor='#9b35ff';x.strokeStyle='#39ffff';x.lineWidth=3;x.beginPath();x.arc(e.x,e.y,e.r,0,Math.PI*2);x.stroke();x.strokeStyle='#a832ff';x.lineWidth=2;x.beginPath();x.arc(e.x,e.y,e.r*.55,0,Math.PI*2);x.stroke();x.restore();if(e.life<=0)teleportEffects.splice(i,1)}}
function drawParticles(){for(let i=parts.length-1;i>=0;i--){let p=parts[i];p.x+=p.vx;p.y+=p.vy;p.vx*=.97;p.vy*=.97;p.life--;x.fillStyle=p.type==='food'?'#fff900':p.type==='hit'?'#fff900':p.type==='fire'?'#ff7a00':'#39ffff';x.shadowBlur=8;x.shadowColor=p.type==='food'?'#fff900':p.type==='hit'?'#fff900':p.type==='fire'?'#ff4500':'#9b35ff';let sz=p.type==='food'?3.5:p.type==='fire'?3.2:4;x.fillRect(p.x,p.y,sz,sz);x.shadowBlur=0;if(p.life<=0)parts.splice(i,1)}}
function loop(now){if(!running)return;let dt=Math.min(50,now-last);last=now;movePlayer(dt);enemies.forEach(e=>moveEnemy(e,dt));if(level>=10&&level10SkillUntil>performance.now())updateBombs(dt);else bombs=[];hit();draw();if(running)requestAnimationFrame(loop)}
const dir={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]};document.querySelectorAll('.ctrl').forEach(b=>b.addEventListener('pointerdown',e=>{e.preventDefault();let d=dir[b.dataset.d];P.nx=d[0];P.ny=d[1];b.classList.add('active')}));addEventListener('pointerup',()=>document.querySelectorAll('.ctrl').forEach(b=>b.classList.remove('active')));addEventListener('keydown',e=>{let d={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[e.key];if(d){e.preventDefault();P.nx=d[0];P.ny=d[1]}});document.querySelectorAll('.mode').forEach(b=>b.onclick=()=>{document.querySelectorAll('.mode').forEach(q=>q.classList.remove('sel'));b.classList.add('sel');diff=b.dataset.v});document.querySelectorAll('.char').forEach(b=>b.onclick=()=>{document.querySelectorAll('.char').forEach(q=>q.classList.remove('sel'));b.classList.add('sel');char=b.dataset.v});document.getElementById('start').onclick=()=>{if(levelMessage){levelMessage=false;maze();foodsMake();enemiesMake();P.x=P.y=1;P.dx=P.dy=P.nx=P.ny=0;parts=[];teleportEffects=[];bombs=[];explosions=[];if(level===10){level10SkillUntil=performance.now()+10000}overlay.classList.add('hide');running=true;last=performance.now();ui();draw();requestAnimationFrame(loop)}else startGame()};maze();foodsMake();enemiesMake();ui();resize();draw();
</script></body></html>`;
  try {
    const responseId = crypto.randomUUID();
    const botResponseId = crypto.randomUUID();

          const payload = {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
              botMetadata: {
                messageDisclaimerText: "",
                botResponseId,
                verificationMetadata: {
                  proofs: [
                    {
                      version: 1,
                      useCase: 1,
                      signature:
                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                      certificateChain: [
                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUd5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ==",
                      ],
                    },
                  ],
                },
              },
            },
            botForwardedMessage: {
              message: {
                richResponseMessage: {
                  messageType: 1,
                  submessages: [
                    {
                      messageType: 2,
                      messageText: "PIXEL MAZE",
                    },
                  ],
                  unifiedResponse: {
                    data: Buffer.from(
                      JSON.stringify({
                        response_id: responseId,
                        sections: [
                          {
                            view_model: {
                              primitive: {
                                __typename: "GenAIaeacdsnwHtmlPrimitive",
                                payload: htmlCode,
                                trusted_sources: ["nixel.dev"],
                              },
                              __typename: "GenAISingleLayoutViewModel",
                            },
                          },
                        ],
                      }),
                    ).toString("base64"),
                  },
                  contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedAiBotMessageInfo: {
                      botJid: "867051314767696@bot",
                    },
                    forwardOrigin: 4,
                  },
                },
              },
            },
          };

          await sock.relayMessage(m.chat, payload, {});

    try { await m.react("🎮"); } catch {}
  } catch (error) {
    console.error("[PIXZO] Error:", error);
    try { await m.react("❌"); } catch {}
    return m.reply(`❌ *Gagal menjalankan PIXZO*\n\n> ${error.message}`);
  }
  return { handled: true };

}

export { pluginConfig as config, handler };
