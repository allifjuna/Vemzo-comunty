const pluginConfig = {
  name: "infobot",
  alias: ["botinfo", "info-bot"],
  category: "info",
  description: "Menampilkan informasi bot dan developer.",
  usage: ".infobot",
  example: ".infobot",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  energi: 0,
  isEnabled: true,
};

async function handler(m, { config, sock }) {
  const userJid = m.sender;
  const number = String(userJid || "").split("@")[0];

  const text =
    `Hallo @${number}\n\n` +
    `Saya adalah asisten bot *VEMZO COMUNTY*. Saya di rancang oleh developer \`ALLIF PROFESOR🔥\` untuk menjaga grup tetap aman dan santai.\n\n` +
    `Saya di rancang untuk bermain bersama kalian ataupun untuk mendownload video lewat media sosial, dan juga untuk mempermudah anda menggunakan stiker otomatis yang sudah di rancang.\n\n` +
    `Mohon *gunain bot secara bijak*.\n\n` +
    `Thanks you dari \`ALLIF PROFESOR\``;

  // Pakai metadata newsletter agar WhatsApp menampilkan CTA native
  // "Lihat saluran" seperti pada preview pesan Channel.
  const saluranId = config.saluran?.id || "";
  const saluranName = config.saluran?.name || "VEMZO COMMUNITY";
  const contextInfo = {
    mentionedJid: [userJid],
    forwardingScore: 1,
    isForwarded: true,
  };

  if (saluranId && saluranId.endsWith("@newsletter")) {
    contextInfo.forwardedNewsletterMessageInfo = {
      newsletterJid: saluranId,
      newsletterName: saluranName,
      serverMessageId: Math.floor(Math.random() * 100000) + 1,
    };
  }

  await m.reply(text, { contextInfo });
}

export { pluginConfig as config, handler };
