import {
    loadSent,
    saveSent,
    loadState,
    saveState,
    getOngoingAnimeList,
    startAutoCheck,
    stopAutoCheck,
    runCheck,
    isRunning
} from '../../src/lib/vemzo-auto-anime.js'
import te from '../../src/lib/vemzo-error.js'

const pluginConfig = {
    name: 'autoanimewinbu',
    alias: ['aaw', 'autoanime'],
    category: 'anime',
    description: 'Auto-notify anime terbaru dari Winbu (Pixeldrain 720p+)',
    usage: '.autoanimewinbu <start|stop|status|cek|list|reset|addgrup|delgrup|interval>',
    example: '.autoanimewinbu start',
    isOwner: true,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 0,
    isEnabled: true
}

function parseArgs(args, text) {
    if (Array.isArray(args) && args.length) return args.map(String)
    return String(text || '').trim().split(/\s+/).filter(Boolean)
}

function getSubcommand(args, text) {
    return parseArgs(args, text)[0]?.toLowerCase() || ''
}

async function handler(m, { sock, args, text }) {
    const parsedArgs = parseArgs(args, text)
    const sub = getSubcommand(args, text)
    const state = loadState()

    switch (sub) {
        case 'start': {
            if (isRunning()) return m.reply('⚠️ *AutoAnime sudah berjalan.*')

            const groups = state.groups || []
            if (!groups.length) {
                return m.reply(
                    `❌ Belum ada grup target!\n\n` +
                    `> Tambahkan grup dulu:\n` +
                    `> \`${m.prefix}autoanimewinbu addgrup\` (di grup target)\n` +
                    `> atau \`${m.prefix}autoanimewinbu addgrup 120363xxx@g.us\``
                )
            }

            const interval = state.interval || 5
            try {
                saveState({ ...state, enabled: true, interval })
                startAutoCheck(sock, interval)
            } catch (e) {
                saveState({ ...state, enabled: false })
                return m.reply(`❌ Gagal menyalakan AutoAnime: ${e.message}`)
            }

            return sock.sendMessage(m.chat, {
                text:
                    `✅ *ᴀᴜᴛᴏ ᴀɴɪᴍᴇ sᴛᴀʀᴛᴇᴅ*\n\n` +
                    `> 📲 Grup target: *${groups.length}*\n` +
                    `> ⏱️ Interval: *${interval} menit*\n` +
                    `> 🎞️ Filter: *Pixeldrain 720p+*\n` +
                    `> ⏰ Max age: *24 jam*\n\n` +
                    `Pengecekan pertama sedang dijalankan...`,
                interactiveButtons: [
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📊 Status',
                            id: `${m.prefix}autoanimewinbu status`
                        })
                    },
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🛑 Stop',
                            id: `${m.prefix}autoanimewinbu stop`
                        })
                    }
                ]
            }, { quoted: m })
        }

        case 'stop': {
            stopAutoCheck()
            saveState({ ...state, enabled: false })
            return m.reply('🛑 *AutoAnime dihentikan.*')
        }

        case 'status': {
            const sent = loadSent()
            const running = isRunning()
            const groups = state.groups || []
            const episodeCount = new Set(
                [...sent]
                    .map(key => String(key).split('::')[0])
                    .filter(Boolean)
            ).size

            let txt = `📊 *ᴀᴜᴛᴏ ᴀɴɪᴍᴇ sᴛᴀᴛᴜs*\n\n`
            txt += `> 🔄 Status: *${running ? '🟢 ON' : '🔴 OFF'}*\n`
            txt += `> 💾 Auto-start: *${state.enabled ? 'Ya' : 'Tidak'}*\n`
            txt += `> 📋 Episode tercatat: *${episodeCount}*\n`
            txt += `> ⏱️ Interval: *${state.interval || 5} menit*\n`
            txt += `> 📲 Grup target: *${groups.length}*\n`

            if (groups.length) {
                txt += `\n*Grup:*\n`
                groups.forEach((g, i) => {
                    txt += `> ${i + 1}. \`${g}\`\n`
                })
            }

            return sock.sendMessage(m.chat, { text: txt }, { quoted: m })
        }

        case 'cek':
        case 'check': {
            await m.reply('🔍 Mengecek anime terbaru...')
            try {
                await runCheck(sock)
                return m.reply('✅ Pengecekan selesai.')
            } catch (e) {
                console.error('[AutoAnime] Manual check:', e)
                return m.reply(te(m.prefix, m.command, m.pushName))
            }
        }

        case 'list': {
            await m.reply('📺 Mengambil daftar anime...')
            try {
                const list = await getOngoingAnimeList()
                if (!list.length) return m.reply('❌ Tidak ada anime ditemukan.')

                let txt = `📺 *ᴅᴀꜰᴛᴀʀ ᴀɴɪᴍᴇ ᴛᴇʀʙᴀʀᴜ*\n\n`
                txt += `> Total: *${list.length}* anime\n\n`
                list.slice(0, 15).forEach((a, i) => {
                    txt += `*${i + 1}.* ${a.title}\n`
                })
                if (list.length > 15) txt += `\n> ...dan ${list.length - 15} lainnya`
                return sock.sendMessage(m.chat, { text: txt }, { quoted: m })
            } catch (e) {
                console.error('[AutoAnime] List:', e)
                return m.reply(te(m.prefix, m.command, m.pushName))
            }
        }

        case 'reset': {
            const sent = loadSent()
            const count = sent.size
            saveSent(new Set())
            return m.reply(`✅ Reset! *${count}* catatan pengiriman dihapus.\n> Episode yang masih tersedia dapat diproses ulang.`)
        }

        case 'addgrup':
        case 'addgroup': {
            const supplied = parsedArgs[1]?.trim()
            const grupId = supplied || (m.isGroup ? m.chat : '')

            if (!grupId || !/\d+@g\.us$/.test(grupId)) {
                return m.reply(
                    `❌ ID grup tidak valid.\n\n` +
                    `> Gunakan command ini di dalam grup, atau:\n` +
                    `> \`${m.prefix}autoanimewinbu addgrup 120363xxx@g.us\``
                )
            }

            const groups = [...new Set(state.groups || [])]
            if (groups.includes(grupId)) return m.reply('⚠️ Grup tersebut sudah ada di daftar target.')
            groups.push(grupId)
            saveState({ ...state, groups })
            return m.reply(`✅ Grup \`${grupId}\` ditambahkan.\n> Total: *${groups.length}* grup`)
        }

        case 'delgrup':
        case 'delgroup': {
            const supplied = parsedArgs[1]?.trim()
            const grupId = supplied || (m.isGroup ? m.chat : '')
            const groups = [...new Set(state.groups || [])]
            const idx = groups.indexOf(grupId)
            if (idx === -1) return m.reply('❌ Grup tidak ditemukan di daftar target.')
            groups.splice(idx, 1)
            saveState({ ...state, groups })
            return m.reply(`✅ Grup \`${grupId}\` dihapus.\n> Sisa: *${groups.length}* grup`)
        }

        case 'interval': {
            const mins = Number(parsedArgs[1])
            if (!Number.isInteger(mins) || mins < 1 || mins > 60) {
                return m.reply(`❌ Interval harus 1-60 menit.\n\n> Contoh: \`${m.prefix}autoanimewinbu interval 10\``)
            }

            saveState({ ...state, interval: mins })
            if (isRunning()) {
                try {
                    startAutoCheck(sock, mins)
                } catch (e) {
                    return m.reply(`❌ Interval tersimpan, tetapi scheduler gagal diperbarui: ${e.message}`)
                }
            }
            return m.reply(`✅ Interval diubah menjadi *${mins} menit*.`)
        }

        default: {
            const running = isRunning()
            return sock.sendMessage(m.chat, {
                text:
                    `🎬 *ᴀᴜᴛᴏ ᴀɴɪᴍᴇ ᴡɪɴʙᴜ*\n\n` +
                    `> Status: *${running ? '🟢 ON' : '🔴 OFF'}*\n\n` +
                    `*ᴄᴏᴍᴍᴀɴᴅs:*\n` +
                    `> \`${m.prefix}aaw start\` — Mulai auto-check\n` +
                    `> \`${m.prefix}aaw stop\` — Hentikan\n` +
                    `> \`${m.prefix}aaw status\` — Lihat status\n` +
                    `> \`${m.prefix}aaw cek\` — Manual check tanpa menyalakan scheduler\n` +
                    `> \`${m.prefix}aaw list\` — Daftar anime terbaru\n` +
                    `> \`${m.prefix}aaw addgrup\` — Tambah grup target\n` +
                    `> \`${m.prefix}aaw delgrup\` — Hapus grup target\n` +
                    `> \`${m.prefix}aaw interval 10\` — Ubah interval\n` +
                    `> \`${m.prefix}aaw reset\` — Reset riwayat terkirim`,
                interactiveButtons: [
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: running ? '🛑 Stop' : '▶️ Start',
                            id: `${m.prefix}autoanimewinbu ${running ? 'stop' : 'start'}`
                        })
                    },
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📊 Status',
                            id: `${m.prefix}autoanimewinbu status`
                        })
                    }
                ]
            }, { quoted: m })
        }
    }
}

export { pluginConfig as config, handler }
