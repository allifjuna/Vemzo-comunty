import config from "../../config.js";

const enabledGroups = global.antiShindraEnabled || (global.antiShindraEnabled = new Set());
const history = global.antiShindraHistory || (global.antiShindraHistory = new Map());

const WINDOW_MS = 60 * 1000;
const LIMIT = 1; // lebih dari 1 = 2 kick

function clean(value) {
  return String(value || "")
    .split(":")[0]
    .split("@")[0]
    .replace(/[^0-9]/g, "");
}

function configuredOwners() {
  const numbers = config?.owner?.number;
  const list = Array.isArray(numbers) ? numbers : [numbers];
  return list.map(clean).filter(Boolean);
}

function isConfiguredOwner(m) {
  const owners = configuredOwners();
  const candidates = [
    m?.sender,
    m?.senderNumber,
    m?.key?.participant,
    m?.key?.participantAlt,
    m?.key?.participantPn,
    m?.key?.remoteJidAlt,
  ].map(clean).filter(Boolean);

  return candidates.some(c =>
    owners.some(o => c === o || c.endsWith(o) || o.endsWith(c))
  );
}

function participantIds(p) {
  if (!p) return [];
  return [
    p.id,
    p.jid,
    p.lid,
    p.phoneNumber,
  ].filter(Boolean).map(String);
}

function sameParticipant(a, b) {
  if (!a || !b) return false;

  const aa = participantIds(a);
  const bb = participantIds(b);

  if (aa.some(x => bb.includes(x))) return true;

  const an = aa.map(clean).filter(Boolean);
  const bn = bb.map(clean).filter(Boolean);

  return an.some(x =>
    bn.some(y => x === y || x.endsWith(y) || y.endsWith(x))
  );
}

function getActor(update) {
  return (
    update?.author ||
    update?.authorPn ||
    update?.authorAlt ||
    update?.participant ||
    update?.participantPn ||
    update?.participantAlt ||
    null
  );
}

function getBotIdentities(sock) {
  return [
    sock?.user?.id,
    sock?.user?.lid,
    sock?.user?.jid,
    sock?.user?.phoneNumber,
  ].filter(Boolean).map(String);
}

function isBotParticipant(participant, sock) {
  const botIds = getBotIdentities(sock);
  if (!participant || !botIds.length) return false;

  if (botIds.some(id => participantIds(participant).includes(id))) return true;

  const botNums = botIds.map(clean).filter(Boolean);
  const partNums = participantIds(participant).map(clean).filter(Boolean);

  return botNums.some(b =>
    partNums.some(p => b === p || b.endsWith(p) || p.endsWith(b))
  );
}

async function statusCommand(m, { args }) {
  if (!isConfiguredOwner(m)) {
    return m.reply("❌ Akses ditolak. Perintah ini hanya untuk owner.");
  }

  const action = String(args?.[0] || "").toLowerCase();

  if (action === "on") {
    enabledGroups.add(m.chat);
    history.delete(m.chat);
    return m.reply(`
╭━━━〔 🛡️ 𝐀𝐍𝐓𝐈 𝐒𝐇𝐈𝐍𝐃𝐑𝐀 〕━━━╮
┃
┃  ✅ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝐀𝐊𝐓𝐈𝐅
┃
┃  Sistem mendeteksi pengeluaran
┃  member secara massal.
┃
┃  ⚠️ Batas : lebih dari 1 member
┃  👑 Admin pelaku : dicopot
┃  🚪 Pelaku : dikeluarkan
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`);
  }

  if (action === "off") {
    enabledGroups.delete(m.chat);
    history.delete(m.chat);
    return m.reply(`
╭━━━〔 🛡️ 𝐀𝐍𝐓𝐈 𝐒𝐇𝐈𝐍𝐃𝐑𝐀 〕━━━╮
┃
┃  ⛔ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝐍𝐎𝐍𝐀𝐊𝐓𝐈𝐅
┃
┃  Proteksi kick massal dimatikan
┃  untuk grup ini.
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`);
  }

  return m.reply(
    `🛡️ *Anti Shindra*: ${enabledGroups.has(m.chat) ? "AKTIF" : "NONAKTIF"}\n\nGunakan *.antishindra on* atau *.antishindra off*`
  );
}

function registerAntiShindra(sock) {
  if (!sock || sock.__antiShindraRegistered) return;
  sock.__antiShindraRegistered = true;

  sock.ev.on("group-participants.update", async update => {
    try {
      if (
        !update ||
        update.action !== "remove" ||
        !update.id ||
        !enabledGroups.has(update.id)
      ) return;

      const actor = getActor(update);
      if (!actor) {
        console.warn("[ANTI-SHINDRA] Event remove tidak memiliki author.");
        return;
      }

      const botIds = getBotIdentities(sock);
      const actorNum = clean(actor);

      // Bot dan owner tidak pernah ditindak.
      if (
        botIds.some(id => id === actor || clean(id) === actorNum) ||
        configuredOwners().some(owner =>
          actorNum === owner || actorNum.endsWith(owner) || owner.endsWith(actorNum)
        )
      ) return;

      const now = Date.now();
      const key = `${update.id}:${actorNum || String(actor)}`;

      const recent = (history.get(key) || [])
        .filter(x => now - x.time <= WINDOW_MS);

      for (const participant of update.participants || []) {
        recent.push({ time: now, participant });
      }

      history.set(key, recent);

      // Baru bertindak setelah KICK ke-2.
      if (recent.length <= LIMIT) return;

      const metadata = await sock.groupMetadata(update.id);
      const participants = metadata?.participants || [];

      // Bot harus admin. Cocokkan via ID/JID/LID/nomor.
      const botParticipant = participants.find(p => isBotParticipant(p, sock));
      if (!botParticipant?.admin) {
        console.warn("[ANTI-SHINDRA] Bot bukan admin.");
        return;
      }

      // Cari pelaku dari ID/JID/LID/nomor.
      const offender = participants.find(p => {
        const ids = participantIds(p);
        if (ids.includes(String(actor))) return true;

        const nums = ids.map(clean).filter(Boolean);
        return actorNum && nums.some(n =>
          n === actorNum || n.endsWith(actorNum) || actorNum.endsWith(n)
        );
      });

      if (!offender) {
        console.warn("[ANTI-SHINDRA] Pelaku tidak ditemukan di metadata:", actor);
        return;
      }

      // Hanya admin yang dicopot lalu dikeluarkan.
      if (!offender.admin) {
        history.delete(key);
        return;
      }

      await sock.groupParticipantsUpdate(update.id, [offender.id], "demote");
      await new Promise(resolve => setTimeout(resolve, 300));
      await sock.groupParticipantsUpdate(update.id, [offender.id], "remove");

      await sock.sendMessage(update.id, {
        text: "⚠️ terdeteksi kick massal harus disingkirkan"
      });

      history.delete(key);
    } catch (error) {
      console.error("[ANTI-SHINDRA]", error);
    }
  });
}

const configPlugin = {
  name: "antishindra",
  alias: ["antishindra"],
  category: "group",
  description: "Proteksi kick massal",
  usage: ".antishindra on|off",
  isGroup: true,
  isOwner: false,
  isEnabled: true,
};

async function handler(m, { sock, args }) {
  await statusCommand(m, { args });
  registerAntiShindra(sock);
}

export { configPlugin as config, handler, registerAntiShindra };
