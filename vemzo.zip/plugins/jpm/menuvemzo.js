import configOwner from "../../config.js";
import { generateWAMessageFromContent } from "ourin";
import { getPluginsByCategory } from "../../src/lib/vemzo-plugins.js";

function clean(v) {
    return String(v || "").split(":")[0].split("@")[0].replace(/[^0-9]/g, "");
}

function isOwner(m) {
    const raw = configOwner?.owner?.number;
    const owners = (Array.isArray(raw) ? raw : [raw]).map(clean).filter(Boolean);

    const senders = [
        m?.sender,
        m?.senderNumber,
        m?.key?.participant,
        m?.key?.participantPn,
        m?.key?.participantAlt,
        m?.key?.participantLid,
    ].map(clean).filter(Boolean);

    return senders.some(s =>
        owners.some(o => s === o || s.endsWith(o) || o.endsWith(s))
    );
}

const config = {
    name: "menuvemzo",
    alias: ["menuvemzo"],
    category: "main",
    description: "Menu Vemzo Security",
    usage: ".menuvemzo",
    isGroup: false,
    isPrivate: false,
    isOwner: true,
    isEnabled: true
};

async function handler(m, { sock }) {
    if (!isOwner(m)) {
        return m.reply("❌ Akses ditolak. Menu ini khusus owner.");
    }

    const prefix = m.prefix || configOwner?.command?.prefix || ".";

    // Tombol di .menuvemzo langsung membuka daftar command group,
    // tanpa mengirim pesan perantara .listmenu terlebih dahulu.
    const plugins = getPluginsByCategory("group")
        .filter((plugin) => plugin?.config?.isEnabled !== false)
        .map((plugin) => plugin.config)
        .sort((a, b) => String(Array.isArray(a.name) ? a.name[0] : a.name)
            .localeCompare(String(Array.isArray(b.name) ? b.name[0] : b.name)));

    const seen = new Set();
    const rows = [];
    for (const info of plugins) {
        const names = Array.isArray(info.name) ? info.name : [info.name];
        const name = String(names[0] || "").trim().toLowerCase();
        if (!name || seen.has(name)) continue;
        seen.add(name);
        const desc = String(info.description || info.usage || "Fitur grup")
            .replace(/\s+/g, " ").trim().slice(0, 70);
        rows.push({ title: `${prefix}${name}`, description: desc, id: `${prefix}${name}` });
    }

    const sections = [];
    for (let i = 0; i < rows.length; i += 10) {
        sections.push({
            title: `GROUP MENU ${Math.floor(i / 10) + 1}`,
            rows: rows.slice(i, i + 10)
        });
    }

    const text = `╭─〔 ✦ 𝐕𝐄𝐌𝐙𝐎 ✦ 〕─╮
│ 𝐒𝐄𝐂𝐔𝐑𝐈𝐓𝐘 𝐌𝐄𝐍𝐔
╰────────────────╯

╭─〔 🛡️ 𝐀𝐍𝐓𝐈 𝐒𝐇𝐈𝐍𝐃𝐑𝐀 〕
│ ⚡ .antishindra on
│ ⚡ .antishindra off
│ Deteksi pengeluaran member beruntun.
╰────────────────╯

╭─〔 ⚔️ 𝐆𝐑𝐎𝐔𝐏 𝐂𝐎𝐍𝐓𝐑𝐎𝐋 〕
│ ☠️ .shindaratensei
│ Khusus nomor bot.
╰────────────────╯

╭─〔 ✦ 𝐀𝐂𝐂𝐄𝐒𝐒 ✦ 〕
│ 👑 Owner Only
│ 📍 Private Chat + Group
╰────────────────╯

╰━━〔 𝐕𝐄𝐌𝐙𝐎 〕━━╯`;

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {},
                interactiveMessage: {
                    body: { text },
                    footer: { text: "Vemzo Security • Pilih menu di bawah" },
                    contextInfo: {
                        mentionedJid: [m.sender],
                        isForwarded: true,
                        forwardingScore: 1
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "☰ LIST MENU GROUP",
                                    sections
                                })
                            },
                        ]
                    }
                }
            }
        }
    }, { quoted: m, userJid: sock.user.jid });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

export { config, handler };
