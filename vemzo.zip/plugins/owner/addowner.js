import config, { getOwnerName } from "../../config.js";
import { getDatabase } from "../../src/lib/vemzo-database.js";
import {
  addJadibotOwner,
  removeJadibotOwner,
  getJadibotOwners,
} from "../../src/lib/vemzo-jadibot-database.js";
import { isLid, lidToJid, resolveAnyLidToJid, isLidConverted } from "../../src/lib/vemzo-lid.js";

const pluginConfig = {
  name: "addowner",
  alias: ["addown", "setowner", "delowner", "dedown", "ownerlist", "listowner"],
  category: "owner",
  description: "Kelola owner bot",
  usage: ".addowner <nomor/@tag/reply>",
  example: ".addowner 6281234567890",
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  energi: 0,
  isEnabled: true,
};

function cleanJid(jid) {
  if (!jid) return null;
  if (isLid(jid)) jid = lidToJid(jid);
  return jid.includes("@") ? jid : `${jid}@s.whatsapp.net`;
}

function extractNumber(m) {
  let target = "";
  if (m.quoted) {
    let sender = m.quoted.sender || "";
    if (isLid(sender) || isLidConverted(sender)) sender = resolveAnyLidToJid(sender, m.groupMembers || []);
    target = sender.replace(/[^0-9]/g, "");
  } else if (m.mentionedJid?.length) {
    let jid = cleanJid(m.mentionedJid[0]);
    if (isLid(jid) || isLidConverted(jid)) jid = resolveAnyLidToJid(jid, m.groupMembers || []);
    target = (jid || "").replace(/[^0-9]/g, "");
  } else if (m.args[0]) {
    target = m.args[0].replace(/[^0-9]/g, "");
  }
  if (target.startsWith("0")) target = `62${target.slice(1)}`;
  return target.length >= 10 && target.length <= 15 ? target : "";
}

function toMentionJid(value) {
  const number = String(value || "").replace(/[^0-9]/g, "");
  return number ? `${number}@s.whatsapp.net` : null;
}

async function handler(m, { jadibotId, isJadibot }) {
  const db = getDatabase();
  const cmd = m.command.toLowerCase();
  const isAdd = ["addowner", "addown", "setowner"].includes(cmd);
  const isDel = ["delowner", "dedown"].includes(cmd);
  const isList = ["ownerlist", "listowner"].includes(cmd);
  if (!db.data.owner) db.data.owner = [];

  if (isList) {
    const owners = isJadibot && jadibotId ? getJadibotOwners(jadibotId) : [...new Set([...(config.owner?.number || []).map(String), ...db.data.owner])];
    if (!owners.length) return m.reply("📋 *DAFTAR OWNER*\n\n> Belum ada owner terdaftar.");
    const mentions = owners.map(toMentionJid).filter(Boolean);
    const text = owners.map((s, i) => {
      const number = String(s).replace(/[^0-9]/g, "");
      return `${i + 1}. 👑 @${number}${getOwnerName(number) !== "Owner" ? ` — *${getOwnerName(number)}*` : ""}`;
    }).join("\n");
    return m.reply(`📋 *DAFTAR OWNER*\n\n${text}\n\nTotal: *${owners.length}* owner`, { mentions });
  }

  if (!isAdd && !isDel) return;
  const target = extractNumber(m);
  if (!target) return m.reply(`👑 *${isAdd ? "ADD" : "DEL"} OWNER*\n\nReply/tag/ketik nomor user\nContoh: \`${m.prefix}${cmd} 6281234567890 NamaOwner\``);

  if (isJadibot && jadibotId) {
    const changed = isAdd ? addJadibotOwner(jadibotId, target) : removeJadibotOwner(jadibotId, target);
    return m.reply(changed ? `✅ Berhasil ${isAdd ? "menambahkan" : "menghapus"} *${target}* ${isAdd ? "sebagai" : "dari"} owner jadibot` : `❌ *${target}* ${isAdd ? "sudah" : "bukan"} owner jadibot.`);
  }

  if (isAdd) {
    if (db.data.owner.includes(target)) return m.reply(`❌ \`${target}\` sudah menjadi owner.`);
    const customName = m.args.slice(1).join(" ").trim();
    db.data.owner.push(target);
    if (customName) {
      const names = db.setting("ownerNames") || {};
      names[target] = customName;
      db.setting("ownerNames", names);
    }
    db.save();
    await m.react("👑");
    return m.reply(`✅ Berhasil menambahkan *${target}* sebagai owner.`);
  }

  const index = db.data.owner.indexOf(target);
  if (index === -1) return m.reply(`❌ \`${target}\` bukan owner tambahan.`);
  db.data.owner.splice(index, 1);
  const names = db.setting("ownerNames") || {};
  delete names[target];
  db.setting("ownerNames", names);
  db.save();
  await m.react("✅");
  return m.reply(`✅ Berhasil menghapus *${target}* dari owner.`);
}

export { pluginConfig as config, handler };
