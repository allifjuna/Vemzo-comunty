import fs from "fs";
import sharp from "sharp";
import { prepareWAMessageMedia, generateWAMessageFromContent } from "ourin";
import config from "../../config.js";
import { getTimeGreeting } from "../../src/lib/vemzo-formatter.js";
import {
  getCommandsByCategory,
  getCategories,
  getPlugin,
} from "../../src/lib/vemzo-plugins.js";
import { getCasesByCategory, getCaseCount } from "../../case/vemzo.js";

const pluginConfig = {
  name: "allmenu",
  alias: ["fullmenu", "am", "allcommand", "semua"],
  category: "main",
  description: "Menampilkan semua fitur bot dengan tampilan ringkas dan rapi",
  usage: ".allmenu [kategori]",
  example: ".allmenu ai",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 0,
  isEnabled: true,
};

const CATEGORY_EMOJIS = {
  owner: "👑",
  main: "🏠",
  utility: "🔧",
  tools: "🛠️",
  fun: "🎮",
  game: "🎯",
  download: "📥",
  search: "🔎",
  sticker: "🖼️",
  media: "🎬",
  ai: "🤖",
  group: "👥",
  religi: "🕌",
  info: "ℹ️",
  cek: "📋",
  economy: "💰",
  user: "👤",
  canvas: "🎨",
  random: "🎲",
  premium: "💎",
  ephoto: "🪄",
  jpm: "📢",
  pushkontak: "📱",
  store: "🛒",
  convert: "🔄",
  primbon: "🔮",
  tts: "🗣️",
  anime: "🍥",
  berita: "📰",
};

const CATEGORY_ORDER = [
  "main", "utility", "tools", "ai", "download", "search", "media",
  "sticker", "game", "fun", "group", "religi", "economy", "canvas",
  "random", "convert", "info", "cek", "user", "premium", "store",
  "ephoto", "jpm", "pushkontak", "primbon", "tts",
  "anime", "berita", "owner",
];

function getModeFilter(m, botMode) {
  const modeConfig = {
    md: { allowed: null, excluded: ["pushkontak", "store", "panel", "otp"] },
    store: { allowed: ["main", "group", "sticker", "owner", "store"], excluded: [] },
    pushkontak: { allowed: ["main", "group", "sticker", "owner", "pushkontak"], excluded: [] },
    all: { allowed: null, excluded: [] },
  };

  const current = modeConfig[botMode] || modeConfig.md;
  return (category) => {
    const cat = category.toLowerCase();
    if (cat === "owner" && !m.isOwner) return false;
    if (current.allowed && !current.allowed.includes(cat)) return false;
    if (current.excluded?.includes(cat)) return false;
    return true;
  };
}

function sortCategories(categories) {
  return [...categories].sort((a, b) => {
    const ai = CATEGORY_ORDER.indexOf(a.toLowerCase());
    const bi = CATEGORY_ORDER.indexOf(b.toLowerCase());
    return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi) || a.localeCompare(b);
  });
}

function normalizeCommands(commands) {
  return [...new Set((commands || []).map(String).filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

function formatCommandList(commands, prefix) {
  return commands.map((cmd) => `${prefix}${cmd}`);
}

function categoryBlock(category, commands, prefix) {
  const emoji = CATEGORY_EMOJIS[category.toLowerCase()] || "📁";
  const title = category.toUpperCase();
  const rows = formatCommandList(commands, prefix);
  let text = `╭─ ${emoji} *${title}* (${commands.length})\n`;
  for (const row of rows) text += `│ • ${row}\n`;
  text += `╰────────`;
  return text;
}

function findRequestedCategory(input, categories) {
  if (!input) return null;
  const wanted = input.toLowerCase().replace(/[^a-z0-9_-]/g, "");
  return categories.find((cat) => cat.toLowerCase() === wanted) || null;
}

async function handler(m, { sock, config: botConfig, db }) {
  const prefix = botConfig.command?.prefix || ".";
  const groupData = m.isGroup ? db.getGroup(m.chat) || {} : {};
  const botMode = groupData.botMode || "md";
  const commandsByCategory = getCommandsByCategory();
  const casesByCategory = getCasesByCategory();
  const visible = getModeFilter(m, botMode);
  const categories = sortCategories(getCategories()).filter(visible);

  const requestedCategory = findRequestedCategory(m.args?.[0], categories);
  const sections = [];
  let totalCommands = 0;

  for (const category of categories) {
    if (requestedCategory && category !== requestedCategory) continue;

    const pluginCommands = normalizeCommands(commandsByCategory[category]);
    const caseCommands = normalizeCommands(casesByCategory[category]);
    const commands = normalizeCommands([...pluginCommands, ...caseCommands]);
    if (!commands.length) continue;

    totalCommands += commands.length;
    sections.push(categoryBlock(category, commands, prefix));
  }

  if (m.args?.[0] && !requestedCategory) {
    const available = categories.map((cat) => cat).join(", ");
    return m.reply(
      `❌ *KATEGORI TIDAK DITEMUKAN*\n\n` +
      `Gunakan *${prefix}allmenu* untuk semua fitur.\n` +
      `Atau *${prefix}allmenu ai* untuk melihat satu kategori.\n\n` +
      `Kategori: ${available}`,
    );
  }

  if (!sections.length) {
    return m.reply("⚠️ *Belum ada fitur yang tersedia pada mode ini.*");
  }

  const user = db.getUser(m.sender) || {};
  const botName = botConfig.bot?.name || "Vemzo";
  const version = botConfig.bot?.version || "1.0.0";
  const greeting = getTimeGreeting();
  const role = m.isOwner ? "Owner 👑" : m.isPremium ? "Premium 💎" : "Member 👤";
  const caseCount = getCaseCount();
  const title = requestedCategory
    ? `${CATEGORY_EMOJIS[requestedCategory.toLowerCase()] || "📁"} ${requestedCategory.toUpperCase()}`
    : "✨ ALL MENU";

  let text = `╭──────────────╮\n`;
  text += `│ ✦ *${botName.toUpperCase()}*\n`;
  text += `│ ${title}\n`;
  text += `╰──────────────╯\n\n`;
  text += `👋 ${greeting}, *${m.pushName || "User"}*\n`;
  text += `◦ ${role} • v${version}\n`;
  text += `◦ ${totalCommands} fitur • ${caseCount} case\n`;
  text += `◦ ${Number(user.koin || 0).toLocaleString("id-ID")} koin • Prefix ${prefix}\n\n`;

  if (!requestedCategory) {
    text += `💡 *Kategori:* ${prefix}allmenu ai\n\n`;
  }

  text += sections.join("\n\n");
  text += `\n\n──────────────\n`;
  text += `⚡ *${botName}*`;

  // Native Flow KHUSUS untuk .allmenu.
  // Dibuat mengikuti struktur Native Flow yang sudah dipakai oleh plugin menu
  // di bot ini: viewOnceMessage -> interactiveMessage -> nativeFlowMessage.
  try {
    const imagePath = botConfig.assets?.vemzo || config.assets?.vemzo;
    const imageBuffer = imagePath && fs.existsSync(imagePath)
      ? fs.readFileSync(imagePath)
      : null;

    const locationThumbnail = imageBuffer
      ? await sharp(imageBuffer).resize(300, 170, { fit: "cover" }).jpeg({ quality: 90 }).toBuffer()
      : null;

    const flowRows = categories.map((category) => {
      const categoryCommands = normalizeCommands([
        ...(commandsByCategory[category] || []),
        ...(casesByCategory[category] || []),
      ]);
      const emoji = CATEGORY_EMOJIS[category.toLowerCase()] || "📁";
      return {
        title: `${emoji} ${category.toUpperCase()}`,
        description: `${categoryCommands.length} fitur tersedia`,
        id: `${prefix}allmenu ${category}`,
      };
    });

    // Satu single_select dengan section kategori. Hindari button tambahan
    // supaya WhatsApp hanya perlu merender satu kontrol Native Flow.
    const sectionsFlow = [];
    const chunkSize = 10;
    for (let i = 0; i < flowRows.length; i += chunkSize) {
      sectionsFlow.push({
        title: `KATEGORI ${Math.floor(i / chunkSize) + 1}`,
        rows: flowRows.slice(i, i + chunkSize).map((row) => ({
          title: row.title,
          description: row.description,
          id: row.id,
        })),
      });
    }

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {},
            interactiveMessage: {
              header: {
                title: `${botName} • ALL MENU`,
                subtitle: `${totalCommands} fitur tersedia`,
                hasMediaAttachment: !!locationThumbnail,
                ...(locationThumbnail
                  ? {
                      locationMessage: {
                        degreesLatitude: 0,
                        degreesLongitude: 0,
                        name: `${botName} • ALL MENU`,
                        address: `${totalCommands} fitur • ${version}`,
                        jpegThumbnail: locationThumbnail,
                      },
                    }
                  : {}),
              },
              body: { text },
              footer: { text: `${botName} • Pilih kategori di bawah` },
              contextInfo: {
                mentionedJid: [m.sender],
                isForwarded: true,
                forwardingScore: 9,
              },
              nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                  bottom_sheet: {
                    in_thread_buttons_limit: 2,
                    divider_indices: [1, 2, 3, 4, 5, 999],
                    list_title: "Pilih kategori menu",
                    button_title: "📋 All Menu",
                  },
                }),
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: "📋 Pilih Kategori",
                      sections: sectionsFlow,
                    }),
                  },
                ],
              },
            },
          },
        },
      },
      { quoted: m, userJid: sock.user.jid },
    );

    await sock.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id,
    });

    if (db.setting("audioMenu") !== false) {
      const audioPath = botConfig.assets?.["vemzo-mp3"] || config.assets?.["vemzo-mp3"];
      if (audioPath && fs.existsSync(audioPath)) {
        try {
          await sock.sendMessage(
            m.chat,
            {
              audio: fs.readFileSync(audioPath),
              mimetype: "audio/mpeg",
              ptt: false,
            },
            { quoted: m },
          );
        } catch (audioError) {
          console.warn("[AllMenu] Audio gagal dikirim:", audioError.message);
        }
      }
    }

  } catch (error) {
    console.error("[AllMenu] Error:", error);
    await m.reply(text);
  }
}

export { pluginConfig as config, handler };
