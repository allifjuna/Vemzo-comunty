import fs from "fs";
import axios from "axios";
import config from "../../config.js";
import { Button, Carousel } from "../../src/lib/vemzo-builder.js";

const pluginConfig = {
  name: "admin",
  alias: ["admins", "pilihadmin"],
  category: "main",
  description: "Menampilkan daftar admin dalam modern card carousel yang bisa digeser",
  usage: ".admin",
  example: ".admin",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 0,
  isEnabled: true,
};

const ADMIN_NUMBERS = [
  "6281292260146",
  "6282113810759",
  "6288219838278",
];

function normalizeJid(value) {
  if (!value) return "";
  const raw = String(value).split(":")[0];
  return raw.includes("@") ? raw : `${raw}@s.whatsapp.net`;
}

async function getImageBuffer(sock, jid, fallback) {
  try {
    const url = await sock.profilePictureUrl(jid, "image");
    const response = await axios.get(url, {
      responseType: "arraybuffer",
      timeout: 12000,
    });
    return Buffer.from(response.data);
  } catch {
    return fallback;
  }
}

async function makeCard(sock, { image, title, body, footer, buttons = [] }) {
  const card = new Button(sock)
    .setImage(image)
    .setTitle(title)
    .setBody(body)
    .setFooter(footer);

  for (const button of buttons) {
    if (!button?.name) continue;
    card.addButton(button.name, button.params || {});
  }

  return card.toCard();
}

async function handler(m, { sock, config: botConfig }) {
  const botName = botConfig.bot?.name || "Vemzo Community";
  const fallbackImage = fs.readFileSync(
    botConfig.assets?.["vemzo"] || config.assets["vemzo"],
  );

  const cards = [];

  for (let index = 0; index < ADMIN_NUMBERS.length; index++) {
    const number = ADMIN_NUMBERS[index];
    const adminJid = normalizeJid(number);
    const adminImage = await getImageBuffer(sock, adminJid, fallbackImage);
    const adminName = `Admin Vemzo ${index + 1}`;

    cards.push(await makeCard(sock, {
      image: adminImage,
      title: `👑 ${adminName}`,
      body:
        `ADMIN INFORMATION  •  ${index + 1}/${ADMIN_NUMBERS.length}\n\n` +
        `✦ Admin ${botName}\n` +
        `✦ Contact : +${number}\n` +
        `✦ Status : 🟢 Online\n\n` +
        `Admin resmi ${botName}.`,
      footer: `${botName}  •  Admin Contact`,
      buttons: [
        {
          name: "cta_url",
          params: {
            display_text: "Chat Admin",
            url: `https://wa.me/${number}?text=${encodeURIComponent(`Halo ${adminName}, saya ingin bertanya tentang ${botName}.`)}`,
          },
        },
        {
          name: "quick_reply",
          params: {
            display_text: "Pilih Admin",
            id: `${botConfig.command?.prefix || "."}admin`,
          },
        },
      ],
    }));
  }

  try {
    const carousel = new Carousel(sock)
      .setBody(
        `♛  ADMIN VEMZO COMMUNITY\n\n` +
        `Pilih admin yang ingin kamu hubungi dari card di bawah.\n\n` +
        `Total Admin: ${ADMIN_NUMBERS.length}\n` +
        `Status: 🟢 Online`,
      )
      .setFooter("Swipe kartu ← → untuk melihat admin.");

    carousel.addCard(cards);
    await carousel.send(m.chat, { quoted: m.raw });
  } catch (error) {
    console.error("ADMIN CAROUSEL ERROR:", error);
    await m.reply(
      "❌ Carousel admin gagal dikirim. Cek log server untuk detail error.",
    );
  }
}

export { pluginConfig as config, handler };
