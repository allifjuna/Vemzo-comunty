import { getAssetBuffer } from "../../src/lib/vemzo-asset-manager.js";
import { runMenuLoading } from "../../src/lib/menu-loading.js";
import config from "../../config.js";

const pluginConfig = {
    name: "sc",
    alias: ["script"],
    category: "main",
    description: "Link script bot VEMZO Community",
    usage: ".sc",
    example: ".sc",
    isPremium: false,
    isOwner: false,
    isBanned: false,
    isAdmin: false,
    cooldown: 10,
    energi: 0,
    isBotAdmin: false,
    isEnabled: true
};

const YOUTUBE_URL = "https://youtube.com/@vemzotrulexs?si=xTQjrxnn2cXJU0EP";

async function handler(m, { sock }) {
    await runMenuLoading(sock, m.chat, "script VEMZO");

    const caption = `🔥 *SC VEMZO COMUNTY* 🔥\n\n` +
        `Ada di sini! Pencet tombol di bawah ini untuk melihat script / channel VEMZO COMUNTY.\n\n` +
        `╭─〔 *VEMZO COMUNTY* 〕\n` +
        `│ 👤 User : @${String(m.sender || "").split("@")[0]}\n` +
        `│ ⚡ Status : Online\n` +
        `╰───────────────`;

    return await sock.sendMessage(m.chat, {
        image: getAssetBuffer("vemzo"),
        caption,
        footer: "VEMZO COMUNTY • SC",
        mentions: m.sender ? [m.sender] : [],
        interactiveButtons: [
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "🔥 KUNJUNGI VEMZO COMUNTY",
                    url: YOUTUBE_URL,
                    merchant_url: YOUTUBE_URL
                })
            }
        ]
    }, { quoted: m });
}

export { pluginConfig as config, handler };
