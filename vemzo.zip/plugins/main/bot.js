import fs from "fs";
import path from "path";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import { getAssetBuffer } from "../../src/lib/vemzo-asset-manager.js";
import { getProfileBuffer } from "../../src/lib/vemzo-profile-picture.js";
import { getDatabase } from "../../src/lib/vemzo-database.js";
import { runMenuLoading } from "../../src/lib/menu-loading.js";
import config, { isSelf } from "../../config.js";

const pluginConfig = {
  name: "bot",
  alias: ["statusbot"],
  category: "main",
  description: "Menampilkan status bot dan status pendaftaran user",
  usage: ".bot",
  example: ".bot",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 0,
  isEnabled: true,
  skipRegistration: true,
};

function currentDateText() {
  const now = new Date();
  const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const months = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  const pad = (n) => String(n).padStart(2, "0");
  return {
    jam: `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`,
    hari: days[now.getDay()],
    tanggal: now.getDate(),
    tahun: now.getFullYear(),
    bulan: months[now.getMonth()],
  };
}

async function getProfile(sock, jid) {
  try {
    const b = await getProfileBuffer(sock, jid);
    if (b?.length) return b;
  } catch {}
  return null;
}

async function buildBotCard(sock, m, user, role, registered) {
  const useAdmin = role === "Admin" || role === "Owner";
  const assetKey = registered
    ? (useAdmin ? "vemzo-admin-daftar" : "vemzo-member-daftar")
    : (useAdmin ? "vemzo-admin-belum-daftar" : "vemzo-member-belum-daftar");
  const base = (() => {
    try {
      const assetPath = config?.assets?.[assetKey];
      if (assetPath && !String(assetPath).startsWith("http")) {
        const fullPath = path.resolve(process.cwd(), assetPath);
        if (fs.existsSync(fullPath)) return fs.readFileSync(fullPath);
      }
    } catch {}
    return getAssetBuffer(assetKey);
  })();
  if (!base) return null;
  try {
    const bg = await loadImage(base);
    const canvas = createCanvas(bg.width, bg.height);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(bg, 0, 0, bg.width, bg.height);

    const w = bg.width, h = bg.height;
    const profileSize = Math.min(h * 0.34, w * 0.19);
    const cx = w * 0.219, cy = h * 0.635;
    const profile = await getProfile(sock, m.sender);
    if (profile) {
      try {
        const img = await loadImage(profile);
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, profileSize / 2, 0, Math.PI * 2);
        ctx.clip();
        const scale = Math.max(profileSize / img.width, profileSize / img.height);
        const dw = img.width * scale, dh = img.height * scale;
        ctx.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
        ctx.restore();
      } catch {}
    }

    if (!registered) return canvas.toBuffer("image/png");

    // Registered card: render every value explicitly so age and coin never
    // fall back to the template's placeholder values.
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const color = role === "Owner" ? "#ffe66d" : role === "Admin" ? "#ff9f43" : "#f7f4ff";
    ctx.fillStyle = color;

    const fit = (value, x, maxWidth, size = 40, min = 24) => {
      let fontSize = size;
      const text = String(value ?? "-");
      while (fontSize > min) {
        ctx.font = `700 ${fontSize}px Arial`;
        if (ctx.measureText(text).width <= maxWidth) break;
        fontSize--;
      }
      ctx.font = `700 ${Math.max(fontSize, min)}px Arial`;
      ctx.fillText(text, x, cy);
    };

    const name = String(user?.regName || m.pushName || "User");
    const age = Number(user?.regAge);
    const ageText = Number.isFinite(age) && age > 0 ? String(age) : "-";
    const coinText = useAdmin ? "∞" : String(Number(user?.koin ?? 0));
    const roleText = role === "Owner" ? "OWNER" : role === "Admin" ? "ADMIN" : "MEMBER";

    fit(name.length > 24 ? name.slice(0, 24) + "…" : name, w * 0.417, w * 0.145, 40, 24);
    fit(ageText, w * 0.569, w * 0.13, 42, 26);
    fit(coinText, w * 0.711, w * 0.13, 42, 26);
    fit(roleText, w * 0.868, w * 0.145, 38, 24);

    return canvas.toBuffer("image/png");
  } catch (e) {
    console.error("bot card:", e.message);
    return base;
  }
}

async function handler(m, { sock }) {
  await runMenuLoading(sock, m.chat, "status bot");
  const db = getDatabase();
  const user = db.getUser(m.sender) || {};
  const registered = Boolean(user.isRegistered);
  const role = m.isOwner ? "Owner" : (m.isGroup && m.isAdmin ? "Admin" : "Member");
  const botUser = isSelf(m.sender);
  const waktu = currentDateText();
  const card = await buildBotCard(sock, m, user, role, registered);
  const mention = m.sender ? `@${String(m.sender).split("@")[0]}` : "kamu";

  const text = `🤖 *HALLO SAYA BOT VEMZO COMUNTY* 🔥\n\n` +
    `Ada yang bisa saya bantu?\n\n` +
    `╭─〔 *STATUS BOT* 〕\n` +
    `│ ⚡ *Bot aktif selama*\n` +
    `│ 🕒 Jam     : *${waktu.jam}*\n` +
    `│ 📅 Hari    : *${waktu.hari}*\n` +
    `│ 🗓️ Tanggal : *${waktu.tanggal}*\n` +
    `│ 📆 Tahun   : *${waktu.tahun}*\n` +
    `│ 🌙 Bulan   : *${waktu.bulan}*\n` +
    `│ 👤 User    : ${mention}\n` +
    `│ 📝 Daftar : ${registered ? "Sudah terdaftar" : "Belum terdaftar"}\n` +
    `│ 🛡️ Jabatan : ${role}\n` +
    `╰───────────────\n\n` +
    (registered || botUser
      ? `✅ Silakan gunakan fitur bot sesuai akses kamu.`
      : `⚠️ Kamu belum terdaftar. Ketik *${m.prefix}daftar nama,umur* terlebih dahulu.`);

  return sock.sendMessage(m.chat, card ? { image: card, caption: text, mentions: m.sender ? [m.sender] : [] } : { text, mentions: m.sender ? [m.sender] : [] }, { quoted: m });
}

export { pluginConfig as config, handler };
