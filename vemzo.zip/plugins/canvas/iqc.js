import { writeFile, mkdir } from 'node:fs/promises';
import { existsSync, unlinkSync } from 'node:fs';
import { join } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const { generateIQC } = require('iqc-canvas');

const pluginConfig = {
    name: 'iqc',
    alias: ['iphonequote', 'fakechat'],
    category: 'canvas',
    description: 'Membuat Fake Quote iOS style.',
    usage: '.iqc [text/reply]',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 2,
    isEnabled: true,
};

const REACTION_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

function getMessageTime(m) {
    let ts = m.messageTimestamp;
    if (ts && typeof ts === 'object' && ts.low !== undefined) ts = ts.low;
    ts = Number(ts) * 1000;
    const date = Number.isFinite(ts) && ts > 0 ? new Date(ts) : new Date();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${hours}.${minutes}`;
}

async function handler(m, { sock, text }) {
    try {
        const targetText = String(text || (m.quoted && m.quoted.text ? m.quoted.text : '')).trim();

        if (!targetText) {
            return m.reply(
                `🩷 *FITUR FAKE QUOTE iOS*\n\n` +
                `Ketik: ${m.prefix}iqc teks kamu\n` +
                `Atau reply pesan lalu ketik ${m.prefix}iqc`
            );
        }

        const timeStr = getMessageTime(m);
        await m.react('🕕');

        // Template ini memakai iqc-canvas yang memang dibuat untuk
        // tampilan chat WhatsApp iPhone: reaction bar + context menu.
        const result = await generateIQC(targetText, timeStr, {
            reactionEmojis: REACTION_EMOJIS,
            showPlusBtn: true,
        });

        if (!result?.success || !result.image) {
            throw new Error('Generator IQC tidak menghasilkan gambar.');
        }

        await sock.sendMessage(
            m.chat,
            { image: result.image, mimetype: 'image/png' },
            { quoted: m.quoted || m }
        );

        await m.react('✅');
    } catch (error) {
        console.error('[iqc error]:', error);
        await m.react('❌');
        await m.reply(
            `❌ *GAGAL MEMPROSES QUOTE*\n\n` +
            `Terjadi kesalahan saat membuat IQC. Coba jalankan npm install lalu restart bot.`
        );
    }
}

export { pluginConfig as config, handler };
