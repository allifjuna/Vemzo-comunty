import { createCanvas, loadImage } from '@napi-rs/canvas'
import axios from 'axios'
import fs from 'fs'
import path from 'path'
import te from '../../src/lib/vemzo-error.js'
import { getAssetBuffer } from '../../src/lib/vemzo-asset-manager.js'

const pluginConfig = {
    name: ['fakecall', 'fakecallwa'],
    alias: [],
    category: 'canvas',
    description: 'Membuat gambar fake call WhatsApp',
    usage: '.fakecall <nama> | <durasi>',
    example: '.fakecall Jack | 03:00',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

const DEFAULT_PP_PATH = path.resolve(process.cwd(), 'assets/image/pp-kosong.jpg')
const REFERENCE_AVATAR_PATH = path.resolve(process.cwd(), 'assets/fakecall-avatar-kesatu.jpg')
const API_URL = 'https://api.zenzxz.my.id/maker/fakecall'
const API_TIMEOUT = 20000

function normalizeDuration(value) {
    const input = String(value || '').trim()
    if (!input) return null

    if (/^\d{1,3}(?::\d{1,2})?$/.test(input)) return input
    if (/^\d{1,3}\.\d{1,2}$/.test(input)) return input
    return null
}

function durationToDisplay(value) {
    const raw = String(value || '').trim()
    if (raw.includes(':')) {
        const [a, b] = raw.split(':')
        return `${a.padStart(2, '0')}:${b.padStart(2, '0')}`
    }

    if (raw.includes('.')) {
        const [a, b] = raw.split('.')
        return `${a.padStart(2, '0')}:${b.padStart(2, '0')}`
    }

    return `${raw.padStart(2, '0')}:00`
}

function getApiImageUrl(data) {
    if (typeof data === 'string') {
        const value = data.trim()
        if (/^https?:\/\//i.test(value)) return value
        try {
            return getApiImageUrl(JSON.parse(value))
        } catch {
            return null
        }
    }

    if (!data || typeof data !== 'object') return null

    const direct = [
        data.url,
        data.image,
        data.imageUrl,
        data.download,
        data.downloadUrl,
        data.result?.url,
        data.result?.image,
        data.result?.imageUrl,
        data.data?.url,
        data.data?.image,
        data.data?.imageUrl,
    ]

    return direct.find(v => typeof v === 'string' && /^https?:\/\//i.test(v.trim()))?.trim() || null
}

function looksLikeImage(buffer) {
    if (!Buffer.isBuffer(buffer) || buffer.length < 8) return false
    if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return true
    if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return true
    if (buffer.subarray(0, 6).toString('ascii') === 'GIF87a' || buffer.subarray(0, 6).toString('ascii') === 'GIF89a') return true
    if (buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP') return true
    if (buffer.subarray(0, 2).toString('ascii') === 'BM') return true
    return false
}

function roundedRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2)
    ctx.beginPath()
    ctx.moveTo(x + radius, y)
    ctx.lineTo(x + w - radius, y)
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius)
    ctx.lineTo(x + w, y + h - radius)
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h)
    ctx.lineTo(x + radius, y + h)
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius)
    ctx.lineTo(x, y + radius)
    ctx.quadraticCurveTo(x, y, x + radius, y)
    ctx.closePath()
}

function drawCircleImage(ctx, image, cx, cy, radius) {
    ctx.save()
    ctx.beginPath()
    ctx.arc(cx, cy, radius, 0, Math.PI * 2)
    ctx.clip()

    const iw = image.width || 1
    const ih = image.height || 1
    const ratio = Math.max((radius * 2) / iw, (radius * 2) / ih)
    const dw = iw * ratio
    const dh = ih * ratio
    const dx = cx - dw / 2
    const dy = cy - dh / 2
    ctx.drawImage(image, dx, dy, dw, dh)
    ctx.restore()
}

function drawPhoneIcon(ctx, cx, cy, scale = 1, rotation = -0.65) {
    ctx.save()
    ctx.translate(cx, cy)
    ctx.rotate(rotation)
    ctx.strokeStyle = '#fff'
    ctx.lineWidth = 7 * scale
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.beginPath()
    ctx.moveTo(-23 * scale, -18 * scale)
    ctx.quadraticCurveTo(-30 * scale, -12 * scale, -24 * scale, 1 * scale)
    ctx.quadraticCurveTo(-17 * scale, 17 * scale, 0 * scale, 24 * scale)
    ctx.quadraticCurveTo(14 * scale, 30 * scale, 20 * scale, 22 * scale)
    ctx.stroke()
    ctx.restore()
}

function drawVideoIcon(ctx, cx, cy, scale = 1) {
    ctx.save()
    ctx.translate(cx, cy)
    ctx.strokeStyle = '#fff'
    ctx.lineWidth = 5 * scale
    ctx.lineJoin = 'round'
    roundedRect(ctx, -24 * scale, -17 * scale, 32 * scale, 34 * scale, 6 * scale)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(8 * scale, -9 * scale)
    ctx.lineTo(25 * scale, -18 * scale)
    ctx.lineTo(25 * scale, 18 * scale)
    ctx.lineTo(8 * scale, 9 * scale)
    ctx.stroke()
    ctx.restore()
}

function drawMoreIcon(ctx, cx, cy) {
    ctx.fillStyle = '#fff'
    for (const dy of [-10, 0, 10]) ctx.fillRect(cx - 2, cy + dy - 2, 4, 4)
}

async function fetchImageBuffer(url) {
    const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 12000,
        maxContentLength: 6 * 1024 * 1024,
        validateStatus: status => status >= 200 && status < 300
    })
    return Buffer.from(response.data)
}

async function getAvatarBuffer(m, sock) {
    // Gambar kesatu yang diberikan pengguna menjadi avatar utama fakecall.
    // Avatar custom/reply tidak dipakai agar hasil selalu konsisten dengan referensi.
    try {
        if (fs.existsSync(REFERENCE_AVATAR_PATH)) {
            const buffer = fs.readFileSync(REFERENCE_AVATAR_PATH)
            if (looksLikeImage(buffer)) return buffer
        }
    } catch (error) {
        console.log('[fakecall] reference avatar unavailable:', error.message)
    }

    const imageSource = m.isImage ? m : (m.quoted?.isImage ? m.quoted : null)

    if (imageSource?.download) {
        try {
            const buffer = await imageSource.download()
            if (looksLikeImage(buffer)) return buffer
        } catch (error) {
            console.log('[fakecall] custom avatar failed:', error.message)
        }
    }

    try {
        const ppUrl = await sock.profilePictureUrl(m.sender, 'image')
        if (ppUrl) {
            const buffer = await fetchImageBuffer(ppUrl)
            if (looksLikeImage(buffer)) return buffer
        }
    } catch (error) {
        console.log('[fakecall] profile avatar unavailable:', error.message)
    }

    try {
        if (fs.existsSync(DEFAULT_PP_PATH)) return fs.readFileSync(DEFAULT_PP_PATH)
        const cached = getAssetBuffer('pp-kosong')
        if (cached) return cached
    } catch {}

    return null
}

async function generateLocalFakeCall(name, duration, avatarBuffer) {
    // Portrait active-call composition based on the supplied reference.
    // Keep the proportions close to a 674x1536 phone screenshot.
    const width = 674
    const height = 1536
    const canvas = createCanvas(width, height)
    const ctx = canvas.getContext('2d')

    // WhatsApp-like dark wallpaper.
    ctx.fillStyle = '#0b141a'
    ctx.fillRect(0, 0, width, height)

    // Low-contrast doodle pattern (original shapes, not a copied wallpaper).
    ctx.save()
    ctx.globalAlpha = 0.085
    ctx.strokeStyle = '#65757d'
    ctx.fillStyle = '#65757d'
    ctx.lineWidth = 1.8
    for (let row = -1, y = 30; y < height + 90; row++, y += 92) {
        for (let col = -1, x = 22; x < width + 100; col++, x += 98) {
            const xx = x + ((row & 1) ? 35 : 0)
            const yy = y

            // Small camera
            roundedRect(ctx, xx, yy, 27, 18, 4)
            ctx.stroke()
            ctx.beginPath()
            ctx.arc(xx + 13.5, yy + 9, 4.5, 0, Math.PI * 2)
            ctx.stroke()

            // Chat bubble
            ctx.beginPath()
            ctx.moveTo(xx + 44, yy + 8)
            ctx.quadraticCurveTo(xx + 44, yy - 2, xx + 55, yy - 2)
            ctx.lineTo(xx + 72, yy - 2)
            ctx.quadraticCurveTo(xx + 82, yy - 2, xx + 82, yy + 8)
            ctx.quadraticCurveTo(xx + 82, yy + 18, xx + 71, yy + 18)
            ctx.lineTo(xx + 60, yy + 18)
            ctx.lineTo(xx + 54, yy + 25)
            ctx.lineTo(xx + 54, yy + 18)
            ctx.quadraticCurveTo(xx + 44, yy + 18, xx + 44, yy + 8)
            ctx.stroke()

            // Music note
            ctx.beginPath()
            ctx.moveTo(xx + 12, yy + 43)
            ctx.lineTo(xx + 12, yy + 63)
            ctx.moveTo(xx + 12, yy + 43)
            ctx.lineTo(xx + 27, yy + 39)
            ctx.lineTo(xx + 27, yy + 56)
            ctx.stroke()
            ctx.beginPath()
            ctx.arc(xx + 7, yy + 64, 5, 0, Math.PI * 2)
            ctx.arc(xx + 22, yy + 57, 5, 0, Math.PI * 2)
            ctx.stroke()

            // Star
            ctx.beginPath()
            for (let i = 0; i < 10; i++) {
                const a = -Math.PI / 2 + i * Math.PI / 5
                const r = i % 2 ? 6 : 13
                const px = xx + 61 + Math.cos(a) * r
                const py = yy + 55 + Math.sin(a) * r
                if (i === 0) ctx.moveTo(px, py)
                else ctx.lineTo(px, py)
            }
            ctx.closePath()
            ctx.stroke()
        }
    }
    ctx.restore()

    // Top header. The reference has no large title, just name and timer.
    ctx.textAlign = 'center'
    ctx.fillStyle = '#f1f3f4'
    ctx.font = 'bold 23px Arial'
    ctx.fillText(name, width / 2, 91)

    ctx.fillStyle = '#aebac1'
    ctx.font = '18px Arial'
    ctx.fillText(durationToDisplay(duration), width / 2, 119)

    // Top-left round minimize/expand control.
    ctx.fillStyle = '#1d292f'
    ctx.beginPath()
    ctx.arc(51, 93, 34, 0, Math.PI * 2)
    ctx.fill()
    ctx.save()
    ctx.strokeStyle = '#f1f3f4'
    ctx.lineWidth = 3.5
    ctx.lineCap = 'round'
    ctx.beginPath()
    ctx.moveTo(39, 103); ctx.lineTo(61, 81)
    ctx.moveTo(42, 81); ctx.lineTo(42, 103); ctx.lineTo(62, 103)
    ctx.stroke()
    ctx.restore()

    // Top-right add participant control.
    ctx.fillStyle = '#1d292f'
    ctx.beginPath()
    ctx.arc(width - 51, 93, 34, 0, Math.PI * 2)
    ctx.fill()
    ctx.save()
    ctx.fillStyle = '#f1f3f4'
    ctx.beginPath()
    ctx.arc(width - 59, 86, 8, 0, Math.PI * 2)
    ctx.fill()
    ctx.beginPath()
    ctx.moveTo(width - 74, 106)
    ctx.quadraticCurveTo(width - 74, 91, width - 59, 91)
    ctx.quadraticCurveTo(width - 44, 91, width - 44, 106)
    ctx.closePath()
    ctx.fill()
    ctx.strokeStyle = '#f1f3f4'
    ctx.lineWidth = 4
    ctx.beginPath()
    ctx.moveTo(width - 35, 82)
    ctx.lineTo(width - 35, 99)
    ctx.moveTo(width - 43, 90.5)
    ctx.lineTo(width - 27, 90.5)
    ctx.stroke()
    ctx.restore()

    // Large centered avatar.
    const centerX = width / 2
    const centerY = 655
    const avatarRadius = 136

    ctx.fillStyle = '#172329'
    ctx.beginPath()
    ctx.arc(centerX, centerY, avatarRadius + 3, 0, Math.PI * 2)
    ctx.fill()

    if (avatarBuffer) {
        try {
            const avatar = await loadImage(avatarBuffer)
            drawCircleImage(ctx, avatar, centerX, centerY, avatarRadius)
        } catch (error) {
            console.log('[fakecall] avatar render failed:', error.message)
        }
    }

    // Bottom control sheet.
    const panelX = 67
    const panelY = 1080
    const panelW = 540
    const panelH = 372

    ctx.fillStyle = '#121c21'
    roundedRect(ctx, panelX, panelY, panelW, panelH, 38)
    ctx.fill()

    const cols = [155, 337, 519]
    const rows = [1163, 1333]
    const buttonRadius = 46

    function controlButton(x, y, label, iconFn, danger = false) {
        ctx.fillStyle = danger ? '#ff0043' : '#1d292e'
        ctx.beginPath()
        ctx.arc(x, y, buttonRadius, 0, Math.PI * 2)
        ctx.fill()

        iconFn(x, y)

        ctx.fillStyle = '#e9edef'
        ctx.textAlign = 'center'
        ctx.font = '16px Arial'
        ctx.fillText(label, x, y + 83)
    }

    function speakerIcon(x, y) {
        ctx.save()
        ctx.fillStyle = '#fff'
        ctx.beginPath()
        ctx.moveTo(x - 22, y - 8)
        ctx.lineTo(x - 10, y - 8)
        ctx.lineTo(x + 6, y - 20)
        ctx.lineTo(x + 6, y + 20)
        ctx.lineTo(x - 10, y + 8)
        ctx.lineTo(x - 22, y + 8)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = '#fff'
        ctx.lineWidth = 3.5
        ctx.lineCap = 'round'
        ctx.beginPath()
        ctx.arc(x + 4, y, 21, -0.85, 0.85)
        ctx.stroke()
        ctx.restore()
    }

    function videoIcon(x, y) {
        ctx.save()
        ctx.fillStyle = '#fff'
        roundedRect(ctx, x - 23, y - 16, 31, 32, 5)
        ctx.fill()
        ctx.beginPath()
        ctx.moveTo(x + 8, y - 9)
        ctx.lineTo(x + 24, y - 18)
        ctx.lineTo(x + 24, y + 18)
        ctx.lineTo(x + 8, y + 9)
        ctx.closePath()
        ctx.fill()
        ctx.restore()
    }

    function muteIcon(x, y) {
        ctx.save()
        ctx.strokeStyle = '#fff'
        ctx.lineWidth = 4
        ctx.lineCap = 'round'
        roundedRect(ctx, x - 9, y - 23, 18, 34, 9)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(x - 21, y - 2)
        ctx.quadraticCurveTo(x - 21, y + 22, x, y + 22)
        ctx.quadraticCurveTo(x + 21, y + 22, x + 21, y - 2)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(x, y + 22); ctx.lineTo(x, y + 32)
        ctx.moveTo(x - 11, y + 32); ctx.lineTo(x + 11, y + 32)
        ctx.stroke()
        ctx.lineWidth = 4.5
        ctx.beginPath()
        ctx.moveTo(x - 24, y - 28); ctx.lineTo(x + 24, y + 28)
        ctx.stroke()
        ctx.restore()
    }

    function moreIcon(x, y) {
        ctx.fillStyle = '#fff'
        for (const dx of [-12, 0, 12]) {
            ctx.beginPath()
            ctx.arc(x + dx, y, 3.5, 0, Math.PI * 2)
            ctx.fill()
        }
    }

    function shareIcon(x, y) {
        ctx.save()
        ctx.fillStyle = '#fff'
        roundedRect(ctx, x - 17, y - 4, 34, 23, 4)
        ctx.fill()
        ctx.beginPath()
        ctx.moveTo(x, y - 27)
        ctx.lineTo(x - 12, y - 13)
        ctx.lineTo(x - 5, y - 13)
        ctx.lineTo(x - 5, y + 2)
        ctx.lineTo(x + 5, y + 2)
        ctx.lineTo(x + 5, y - 13)
        ctx.lineTo(x + 12, y - 13)
        ctx.closePath()
        ctx.fill()
        ctx.restore()
    }

    function endCallIcon(x, y) {
        drawPhoneIcon(ctx, x, y, 0.67, 2.55)
    }

    controlButton(cols[0], rows[0], 'Speaker', speakerIcon)
    controlButton(cols[1], rows[0], 'Video', videoIcon)
    controlButton(cols[2], rows[0], 'Bisukan', muteIcon)
    controlButton(cols[0], rows[1], 'Lainnya', moreIcon)
    controlButton(cols[1], rows[1], 'Bagikan', shareIcon)
    controlButton(cols[2], rows[1], 'Akhiri', endCallIcon, true)

    // Black navigation bar at the bottom, as in the reference screenshot.
    ctx.fillStyle = '#000'
    ctx.fillRect(0, height - 62, width, 62)

    // Simple Android navigation glyphs.
    ctx.strokeStyle = '#9aa0a6'
    ctx.lineWidth = 3
    ctx.strokeRect(130, height - 43, 18, 18)
    ctx.beginPath()
    ctx.arc(width / 2, height - 34, 9, 0, Math.PI * 2)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(width - 151, height - 26)
    ctx.lineTo(width - 142, height - 43)
    ctx.lineTo(width - 133, height - 26)
    ctx.stroke()

    return canvas.toBuffer('image/png')
}

async function tryRemoteApi(name, duration, avatarBuffer) {
    // Keep the remote API as a best-effort optimization only. The feature no longer
    // depends on it, so a provider outage cannot break the command.
    try {
        const params = { nama: name, durasi: durationToDisplay(duration) }

        if (avatarBuffer) {
            // Do not upload private/custom images to another service. The local renderer
            // handles custom avatars directly, so the remote path intentionally skips it.
            delete params.avatar
        }

        const response = await axios.get(API_URL, {
            params,
            responseType: 'arraybuffer',
            timeout: API_TIMEOUT,
            maxContentLength: 12 * 1024 * 1024,
            validateStatus: status => status >= 200 && status < 300
        })

        const body = Buffer.from(response.data)
        const contentType = String(response.headers?.['content-type'] || '').toLowerCase()

        if (looksLikeImage(body) || contentType.startsWith('image/')) return body

        const text = body.toString('utf8').trim()
        const url = getApiImageUrl(text)
        if (url) return url
    } catch (error) {
        console.log('[fakecall] remote API unavailable, using local renderer:', error.message)
    }

    return null
}

async function handler(m, { sock }) {
    const text = String(m.text || '').trim()

    if (!text.includes('|')) {
        return m.reply(
            `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
            `> \`${m.prefix}fakecall <nama> | <durasi>\`\n\n` +
            `> Contoh: \`${m.prefix}fakecall Jack | 03:00\`\n\n` +
            `💡 *Avatar:* menggunakan gambar kesatu yang sudah dipasang di fitur`
        )
    }

    const [rawNama, ...durationParts] = text.split('|')
    const nama = rawNama.trim()
    const durasi = durationParts.join('|').trim()

    if (!nama) return m.reply('❌ Nama tidak boleh kosong!')
    if (nama.length > 60) return m.reply('❌ Nama terlalu panjang. Maksimal 60 karakter.')

    const normalizedDuration = normalizeDuration(durasi)
    if (!normalizedDuration) {
        return m.reply(
            '❌ Format durasi tidak valid.\n\n' +
            `Contoh: \`${m.prefix}fakecall Jack | 03:00\``
        )
    }

    await m.react('🕕')

    try {
        const avatarBuffer = await getAvatarBuffer(m, sock)

        // Prefer local rendering so the command keeps working when the third-party
        // provider is down. A successful remote response is still accepted.
        const result = await generateLocalFakeCall(nama, normalizedDuration, avatarBuffer)

        await sock.sendMedia(m.chat, result, null, m, { type: 'image' })
        await m.react('📞')
    } catch (error) {
        console.log('[fakecall] Error:', error)
        await m.react('❌')
        return m.reply(te(m.prefix, m.command, m.pushName))
    }
}

export { pluginConfig as config, handler }
