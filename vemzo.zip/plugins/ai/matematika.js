import axios from 'axios'
import config from '../../config.js'
import vemzoApi from '../../src/lib/vemzo-apimanager.js'

// Menyimpan soal yang sedang aktif per chat + user.
// Jawaban dapat dikirim langsung tanpa prefix, misalnya: 1250
const pendingChallenges = new Map()
const CHALLENGE_TTL = 60_000

const pluginConfig = {
    name: 'matematika',
    alias: ['mathgpt', 'math', 'mathsolver'],
    category: 'ai',
    description: 'AI untuk menyelesaikan soal matematika',
    usage: '.matematika <soal>',
    example: '.matematika 2+2 berapa?',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 1,
    isEnabled: true
}

function cleanAnswer(value) {
    if (value == null) return ''
    if (typeof value === 'string') return value.trim()
    if (typeof value === 'number' || typeof value === 'boolean') return String(value)
    if (typeof value === 'object') {
        for (const key of ['result', 'answer', 'solution', 'response', 'text', 'content', 'message', 'data']) {
            if (value?.[key] != null) {
                const nested = cleanAnswer(value[key])
                if (nested) return nested
            }
        }
    }
    return ''
}

function extractAnswer(data) {
    return cleanAnswer(data?.result) ||
        cleanAnswer(data?.answer) ||
        cleanAnswer(data?.solution) ||
        cleanAnswer(data?.response) ||
        cleanAnswer(data?.data) ||
        cleanAnswer(data)
}

function normalizeExpression(text) {
    return String(text || '')
        .toLowerCase()
        .replace(/(berapa|hitung|hasilnya|adalah|sama dengan|hasil dari)/g, ' ')
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/[−–—]/g, '-')
        .replace(/,/g, '.')
        .replace(/\^/g, '^')
        .replace(/²/g, '^2')
        .replace(/³/g, '^3')
        .replace(/\s+/g, ' ')
        .trim()
}

function tokenizeExpression(expr) {
    const tokens = []
    const re = /\d+(?:\.\d+)?|[()+\-*/%^]/g
    let last = 0
    let match
    while ((match = re.exec(expr))) {
        if (expr.slice(last, match.index).trim()) return null
        tokens.push(match[0])
        last = re.lastIndex
    }
    if (expr.slice(last).trim()) return null
    return tokens
}

function evaluateArithmetic(text) {
    const expr = normalizeExpression(text)
    if (!expr) return null

    const tokens = tokenizeExpression(expr)
    if (!tokens) return null

    // Support unary minus by inserting 0 before it.
    const normalized = []
    for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i]
        if (token === '-' && (i === 0 || ['(', '+', '-', '*', '/', '%', '^'].includes(tokens[i - 1]))) {
            normalized.push('0', '-')
        } else {
            normalized.push(token)
        }
    }

    const output = []
    const ops = []
    const prec = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 3 }
    const rightAssoc = new Set(['^'])

    for (const token of normalized) {
        if (/^\d/.test(token)) {
            output.push(Number(token))
        } else if (token === '(') {
            ops.push(token)
        } else if (token === ')') {
            while (ops.length && ops.at(-1) !== '(') output.push(ops.pop())
            if (ops.pop() !== '(') return null
        } else {
            while (
                ops.length &&
                ops.at(-1) !== '(' &&
                (prec[ops.at(-1)] > prec[token] ||
                    (prec[ops.at(-1)] === prec[token] && !rightAssoc.has(token)))
            ) {
                output.push(ops.pop())
            }
            ops.push(token)
        }
    }

    while (ops.length) {
        const op = ops.pop()
        if (op === '(') return null
        output.push(op)
    }

    const stack = []
    for (const token of output) {
        if (typeof token === 'number') {
            stack.push(token)
            continue
        }

        if (stack.length < 2) return null
        const b = stack.pop()
        const a = stack.pop()
        let value

        if (token === '+') value = a + b
        else if (token === '-') value = a - b
        else if (token === '*') value = a * b
        else if (token === '/') {
            if (b === 0) return null
            value = a / b
        } else if (token === '%') {
            if (b === 0) return null
            value = a % b
        } else if (token === '^') {
            value = a ** b
        } else return null

        if (!Number.isFinite(value)) return null
        stack.push(value)
    }

    return stack.length === 1 && Number.isFinite(stack[0]) ? stack[0] : null
}

function formatNumber(value) {
    if (!Number.isFinite(value)) return ''
    if (Number.isInteger(value)) return String(value)
    return String(Number(value.toFixed(10)))
}

function localArithmetic(text) {
    const result = evaluateArithmetic(text)
    if (result == null) return ''
    return `🧮 *Hasil:* ${formatNumber(result)}`
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min
}

function createMathChallenge(level = 'easy') {
    let expression

    if (level === 'easy') {
        const a = randomInt(2, 20)
        const b = randomInt(2, 20)
        const op = ['+', '-', '×'][randomInt(0, 2)]
        expression = `${a} ${op} ${b}`
    } else if (level === 'medium') {
        const a = randomInt(10, 50)
        const b = randomInt(2, 15)
        const c = randomInt(2, 12)
        const op = randomInt(0, 1) ? '+' : '-'
        expression = `(${a} ${op} ${b}) × ${c}`
    } else {
        const a = randomInt(20, 90)
        const b = randomInt(2, 15)
        const c = randomInt(3, 12)
        const d = randomInt(2, 9)
        expression = `(${a} + ${b}) × ${c} − ${d}²`
    }

    const answer = evaluateArithmetic(expression)
    return {
        expression,
        answer,
        text:
            `🧠 *MATH ${level.toUpperCase()}*\n\n` +
            `Soal: *${expression} = ?*\n\n` +
            `⏱️ Waktu: 60 detik\n` +
            `Ketik jawaban angkanya saja.`
    }
}

function saveChallenge(key, challenge) {
    const timeout = setTimeout(() => pendingChallenges.delete(key), CHALLENGE_TTL)
    pendingChallenges.set(key, {
        answer: challenge.answer,
        expression: challenge.expression,
        timeout
    })
}

function clearChallenge(key) {
    const current = pendingChallenges.get(key)
    if (current?.timeout) clearTimeout(current.timeout)
    pendingChallenges.delete(key)
}

async function fetchMath(text) {
    const errors = []

    if (config.APIkey?.covenant) {
        try {
            const data = await vemzoApi.covenant.mathGpt(text, {
                timeout: 30000,
                headers: { Accept: 'application/json' }
            })
            const answer = extractAnswer(data)
            if (answer) return answer
            errors.push('Covenant kosong')
        } catch (error) {
            errors.push(error?.response?.data?.message || error?.message || 'Covenant gagal')
        }
    }

    try {
        const { data } = await axios.get('https://api.nexray.web.id/ai/mathgpt', {
            params: { text },
            timeout: 30000,
            headers: { 'User-Agent': 'VemzoBot/3.3' }
        })
        const answer = extractAnswer(data)
        if (answer) return answer
        errors.push('Nexray kosong')
    } catch (error) {
        errors.push(error?.response?.data?.message || error?.message || 'Nexray gagal')
    }

    const fallback = localArithmetic(text)
    if (fallback) return fallback

    const err = new Error(errors.join(' | ') || 'Tidak ada hasil matematika')
    err.details = errors
    throw err
}

function normalizeMode(value) {
    const mode = String(value || '').trim().toLowerCase()
    if (['easy', 'esy', 'e', 'mudah'].includes(mode)) return 'easy'
    if (['medium', 'med', 'm', 'sedang'].includes(mode)) return 'medium'
    if (['hard', 'h', 'sulit'].includes(mode)) return 'hard'
    return null
}

async function handler(m) {
    const text = String(m.args?.join(' ') || m.text || '').trim()
    const key = `${m.chat}:${m.sender}`

    if (!text) {
        return m.reply(
            `📐 *MATH*\n\n` +
            `> Ketik soal matematika untuk dihitung.\n` +
            `> Mode tantangan: ${m.prefix}math easy | medium | hard\n` +
            `> Contoh: ${m.prefix}math 25 × 4\n` +
            `> Catatan: *esy* juga diterima sebagai *easy*.`
        )
    }

    const mode = normalizeMode(text)
    if (mode) {
        clearChallenge(key)
        const challenge = createMathChallenge(mode)
        saveChallenge(key, challenge)
        return m.reply(challenge.text)
    }

    // Kalau user memakai `.math 25 × 4`, proses lokal dulu agar cepat dan stabil.
    const local = localArithmetic(text)
    if (local) return m.reply(local)

    try {
        m.react('🕕').catch(() => {})
        const answer = await fetchMath(text)
        m.react('✅').catch(() => {})
        return m.reply(`🧠 *Math GPT*\n\n${answer}`)
    } catch (error) {
        console.error('[MATEMATIKA]', error)
        m.react('❌').catch(() => {})
        return m.reply(
            `⚠️ *Soal belum bisa diproses.*\n\n` +
            `Coba contoh: \`${m.prefix}math 25 × 4\`\n` +
            `atau: \`${m.prefix}math easy\`, \`${m.prefix}math medium\`, \`${m.prefix}math hard\``
        )
    }
}

// Dipanggil oleh handler utama untuk menangkap jawaban tantangan tanpa prefix.
async function answerHandler(m) {
    if (!m?.body || m.isCommand) return false

    const key = `${m.chat}:${m.sender}`
    const challenge = pendingChallenges.get(key)
    if (!challenge) return false

    const text = String(m.body).trim().replace(',', '.')
    if (!/^-?\d+(?:\.\d+)?$/.test(text)) return false

    const given = Number(text)
    clearChallenge(key)

    if (given === challenge.answer) {
        await m.reply(`✅ *Benar!* 🎉\nJawaban: *${formatNumber(challenge.answer)}*`)
    } else {
        await m.reply(
            `❌ *Belum benar.*\n` +
            `Jawaban yang benar: *${formatNumber(challenge.answer)}*\n` +
            `Soal: *${challenge.expression}*`
        )
    }

    return true
}

export { pluginConfig as config, handler, answerHandler as mathAnswerHandler }
